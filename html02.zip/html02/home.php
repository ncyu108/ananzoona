<!DOCTYPE html>
<html>
<head>
<title>Home</title>
</head>
<body>
<?php
	session_start();
	echo $_SESSION["useraccount"];
		//echo $_SESSION["UserName"];
?>
</body>
</html>