<!DOCTYPE html>
<?php session_start();?>
<html>

<meta charset="utf-8" />
<head>
<title>首頁</title>
<link href="default.css" rel="stylesheet" type="text/css" media="all" />
<link href="fonts.css" rel="stylesheet" type="text/css" media="all" />
</head>
<body>
<div id="header-wrapper">
	<div id="header" class="container">
		<div id="logo">
		<name>歡迎，<?php echo $_SESSION['username'];if($_SESSION['userisonline']==1) {echo '上線中';}?>
		，會員種類：<strong><?php echo $_SESSION['usertype']."</br>";?></strong></name>
		</div>
		<div id="menu">
		<img src="images/logo_white.png" width="200" height="70" />
		
			<ul>
				<li><a href="student_manage.php" accesskey="1" >學生管理</a></li>
				<li><a href="0815.php?sel=<?php 
							include("connect.php");
							mysqli_select_db($db, "ananzoona" );
							$sql2 = "SELECT 學年度 FROM safereport order by 學年度 DESC limit 1";
							$rows2 = mysqli_query($db , $sql2);//執行SQL查詢
							$row = mysqli_fetch_row($rows2);
							echo $row[0];
							?>&check=0" accesskey="2" >安全回報</a></li>
				<li><a href="message_manage.php" accesskey="3" ><?php 
				include("connect.php");
				mysqli_select_db($db, "ananzoona" );

				$account = $_SESSION['useraccount'];
				$sql = "SELECT 帳號 FROM member where 帳號 != '$account';";
				$rows = mysqli_query($db , $sql);//執行SQL查詢
				$num = mysqli_num_rows ($rows);

				if($num >0)
				{
					for($i=0 ; $i<$num ; $i++)
					{
						$row = mysqli_fetch_row($rows);
						$name = $row[0];
						$messenge_account = $row[0];
						//查詢未讀紀錄//////////////////////////////////////////////////////////////////////////////////////////////////////////
						$select = "SELECT ID FROM message where 接收者帳號 = '$account' && 已讀 = '0';";/////
						$rows2 = mysqli_query($db , $select);//執行SQL查詢//////////////////////////////////////////////////////////////////////
						$num2 = mysqli_num_rows ($rows2);///////////////////////////////////////////////////////////////////////////////////////
						//查詢未讀紀錄//////////////////////////////////////////////////////////////////////////////////////////////////////////
						$num2 =+ $num2;
					}
					if($num2 != 0)
					{	
						echo '訊息通知 '.$num2;//顯示未讀訊息數量
					}
					else
					{
						echo '訊息通知 0';
					}
				}
				mysqli_free_result($rows);
				mysqli_close($db);
			?></a></li>
				<li><a href="member_manage.php" accesskey="4" >個人資訊</a></li>
				<li><a href="member_manager.php" accesskey="5" >帳號管理</a></li>
				<li><a href="suggest.php" accesskey="6" >聯繫我們</a></li>
				
				 <?php 
					$usertype = $_SESSION['usertype'];
					if ($usertype == '超級使用者')
					{ 
						echo '<li><a href="register0913.html" accesskey="7">匯入帳號</a></li>';
					}
				?>
				
				<li><a href="logout.php" accesskey="8" >　登出　</a></li>
			</ul>
			
		</div>
	</div>
</div>
<div class="wrapper">
	<div id="welcome" class="container">
   
	</div>
	<form method="post">
		<select name="type">
			<option value='0'>全部學生</option>
			<option value='1'>已通過</option>
			<option value='2'>未通過</option>
		</select>
		<input type="submit" name="button" id="button" value="搜尋"/>
	</form>
<div id="banner" class="container"><iframe src="http://localhost/html02/map6.html" width="1200" height="600"></iframe></div>
</div>
<div id="copyright">
	<p>&copy; 國立嘉義大學資訊管理學系　<br>服務時間：08:00～17:00　聯絡電話：05-2717312　傳真電話：05-2717318　24小時緊急聯絡專線：05-2717373　E-Mail：meo@mail.ncyu.edu.tw</p>
</div>
</body>
</html>
<?php

// 開啟XML檔案，NODE
if (isset($_POST['type']))
{
	$_SESSION['type'] = $_POST['type'];
}
else
{
	$_SESSION['type'] = 1;
}
?>
		

























