<!DOCTYPE html>
<?php session_start();?>
<html>

<meta charset="utf-8" />
<head>
<title>Home</title>
<link href="css/website.css" rel="stylesheet" type="text/css">

</head>
<body>
<div id="header">
<img src="css/images/logo.png" alt="logo" width="400" height="90" class="headerLogo transition" />
<form>
<h4>
歡迎 <?php echo $_SESSION['username'];if($_SESSION['userisonline']==1) {echo '上線中';}?></br>
會員種類 <?php echo $_SESSION['usertype']."</br>";?></h4>
</form>
<a href="logout.php"><img src="css/images/email.png" alt="登出" width="70" height="30" class="email transition" /></a></div>
<div id="content">
  <div id="contentL">
    <div id="sidemenu">
	<a href="student_manage.php" method="post"><img src="css/images/about_btn.png" alt="學生管理" width="130" height="120" class="transition" /></a>
	<a href="0815.php?sel=<?php 
							include("connect.php");
							mysqli_select_db($db, "ananzoona" );
							$sql2 = "SELECT 學年度 FROM safereport order by 學年度 DESC limit 1";
							$rows2 = mysqli_query($db , $sql2);//執行SQL查詢
							$row = mysqli_fetch_row($rows2);
							echo $row[0];
							?>&check=0" method="post"><img src="css/images/works_btn.png" alt="安全回報管理" width="130" height="120" class="transition" /></a></div>
    <div id="listNew">
	  <p>
        <a href="message_manage.php" >訊息
			<?php 
				include("connect.php");
				mysqli_select_db($db, "ananzoona" );

				$account = $_SESSION['useraccount'];
				$sql = "SELECT 帳號 FROM member where 帳號 != '$account';";
				$rows = mysqli_query($db , $sql);//執行SQL查詢
				$num = mysqli_num_rows ($rows);

				if($num >0)
				{
					for($i=0 ; $i<$num ; $i++)
					{
						$row = mysqli_fetch_row($rows);
						$name = $row[0];
						$messenge_account = $row[0];
						//查詢未讀紀錄//////////////////////////////////////////////////////////////////////////////////////////////////////////
						$select = "SELECT ID FROM message where 接收者帳號 = '$account' && 已讀 = '0';";/////
						$rows2 = mysqli_query($db , $select);//執行SQL查詢//////////////////////////////////////////////////////////////////////
						$num2 = mysqli_num_rows ($rows2);///////////////////////////////////////////////////////////////////////////////////////
						//查詢未讀紀錄//////////////////////////////////////////////////////////////////////////////////////////////////////////
						$num2 =+ $num2;
					}
					if($num2 != 0)
					{	
						echo $num2;//顯示未讀訊息數量
					}
					else
					{
						echo '沒有新訊息';
					}
				}
				mysqli_free_result($rows);
				mysqli_close($db);
			?>
		</a>
	  </p> 
      <p>
        <a href="member_manage.php">個人資訊管理</a></p>
	  <p>
        <a href="member_manager.php">帳號密碼管理</a></p>
	  <p <?php 
			$usertype = $_SESSION['usertype'];
			if ($usertype != '超級使用者')
			{ 
				echo 'hidden=""';
			}
		?>>
        <a href="register.html">匯入帳號</a></p>
	  <p>
        <a href="suggest.php">聯繫我們</a></p><p>
    </div>
  </div>
  <div id="contentR">
    <div id="contentMain">
	<form method="post">
		<select name="type">
			<option value='1'>全部學生</option>
			<option value='2'>已通過</option>
			<option value='3'>未通過</option>
		</select>
		<input type="submit" name="button" id="button" value="搜尋"/>
	</form>
	 <iframe src="http://localhost/html02/map6.html" width="480" height="480"></iframe>
    </div>
  </div>
</div>
<div id="footer"></div>
</body>
</html>





<?php

// 開啟XML檔案，NODE
if (isset($_POST['type']))
{
	$_SESSION['type'] = $_POST['type'];
	echo $_SESSION['type'];
	/*
$dom = new DOMDocument("1.0");
$node = $dom->createElement("markers");
$parnode = $dom->appendChild($node);
//連線
$db=mysqli_connect ('104.198.121.63','root','ananzoona');
mysqli_select_db($db,"ananzoona" );
$sql = "SELECT * FROM maptest ";
$rows = mysqli_query($db , $sql);

$type = $_POST['type'];

$sql2 = "SELECT * FROM maptest WHERE type='1'";
$rows2 = mysqli_query($db , $sql2);

header("Content-type: text/xml");
//讀取到XML檔

while ($row = mysqli_fetch_assoc($rows2)){
  // Add to XML document node
  $node = $dom->createElement("marker");
  $newnode = $parnode->appendChild($node);
  $newnode->setAttribute("id",$row['ID']);
  $newnode->setAttribute("name",$row['name']);
  $newnode->setAttribute("address", $row['address']);
  $newnode->setAttribute("lat", $row['lat']);
  $newnode->setAttribute("lng", $row['lng']);
  $newnode->setAttribute("type", $row['type']);
}

echo $dom->saveXML();
*/
}
?>
		

























