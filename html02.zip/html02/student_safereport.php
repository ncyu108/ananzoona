<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>學生資訊</title>
<link href="css/style3.css" rel="stylesheet" type="text/css">
<link href="css/back.css" rel="stylesheet" type="text/css">
</head>
<center>
<body>
<a href="home.php"><img src="css/images/logo.png" width="500" height="100" /></a>
<table border="1">
	<thead>
		<tr>
			<th>學年度</th>
			<th>學號</th>
			<th>回報資訊</th>
		</tr>
	</thead>
	<tbody>
<?php session_start(); ?>
<?php
include("connect.php");
mysqli_select_db($db, "ananzoona" );
$account = $_GET['account'];
$usertype = $_SESSION['usertype'];
$useraccount = $_SESSION['useraccount'];
if ($usertype == '導師')
{
	$sql = "SELECT * FROM safereport WHERE 成員 = '$account' order by 學年度 DESC";
	$rows = mysqli_query($db , $sql);//執行SQL查詢
	$num = mysqli_num_rows ($rows);
	
	if($num >0)
			{
				for($i=0 ; $i<$num ; $i++)
				{
					$row = mysqli_fetch_row($rows);
					$name = $row[0];
					echo "<tr>";
					echo "<td>" . $row[13] . "</td>";
					echo "<td>" . $row[2] . "</td>";
					echo "<td>"."<a href ='safereport.php?name=$row[1]&year=$row[13]'>$row[13]</a>"."</td>";
					echo "</br>";
				}
				mysqli_free_result($rows);
			}
}
mysqli_close($db);
?>
</tbody>
	<form>
	<br><a href="student_manage.php"><img src="css/images/back.png" alt="back" width="100" height="50" /></a></br>
		<!--<input type="submit" name="gohome" value="回首頁" formaction="home.php"/>-->
	</form>
</body>
</center>
</html>