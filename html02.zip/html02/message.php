<?php session_start();?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>login</title>
</head>
<body>

<?php
$db = @mysqli_connect('104.198.121.63','root','ananzoona');
if ( !$db ) {
	
	echo "MySQL伺服器連接錯誤!<br/>";
	exit();
	
}
else {
	
	echo "MySQL伺服器連接成功!<br/>";
	
}
mysqli_select_db($db, "ananzoona" );

$name=$_SESSION["username"];
$id=$_SESSION["useraccount"];
$text = $_POST["Message"];
$query = mysqli_query($db,"insert into sugeest (帳號,姓名,內容) values ('$id','$name','$text')");
if ($query) {
	
	$result = "上傳成功";
    echo '上傳成功!';
	
}
else{ 

	$result = "上傳失敗<br/>".mysqli_error($db);
    echo $result;
	
}
mysqli_close($db);
?>
</body>
</html>