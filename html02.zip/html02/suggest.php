<!doctype>
<html>
<head>
<meta charset="utf-8"/>
<link href="css/website.css" rel="stylesheet" type="text/css">
<title>留言</title>
</head>
<body>
<div id="header"><a href="home.php"><img src="css/images/ncyu_logo.png" alt="logo" width="400" height="90" class="headerLogo transition" /></a>
<div id="content">
  <div id="contentL">
    <div id="sidemenu">
<form action="message.php" method="post">
			<h1>姓名：
			<?php
				session_start();
				echo $_SESSION["username"]; 
			?></h1>
			<h1>留言：</h1>
				<textarea name="Message" row="4" cols="30"></textarea>
		</tr>
	<input type="submit" name="Send" value="送出留言">
	<input type="reset" name="Reset" value="重設欄位">
	<input type="submit" name="gohome" value="回首頁" formaction="home.php"/>
</form>
<div id="contentR">
    <div id="contentMain">
      <p class="subtitle"></p>
    </div>
  </div>
</div>
<div id="footer"></div>
</body>
</html>
