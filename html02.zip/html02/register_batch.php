<?php
$db = @mysqli_connect('104.198.121.63','root','ananzoona');
$action = $_GET['action']; 
if ($action == 'import') //匯入CSV 
{ 
//匯入處理 
	$filename = $_FILES['file']['tmp_name']; 
	$extension= pathinfo($_FILES['file']['name'],PATHINFO_EXTENSION);//取得檔案副檔名
	if(in_array($extension,array('csv'))){//檢查檔案副檔名
	
		echo '允許該檔案格式';
	
	}
	else{
		
		echo '不允許該檔案格式';
		echo '<meta http-equiv=REFRESH CONTENT=1;url=register.html>';
		exit; 
		
	}
	if(	empty($filename)) { 
	
		echo '請確認要匯入的CSV檔案！'; 
		echo '<meta http-equiv=REFRESH CONTENT=1;url=register.html>';
		exit; 
		
	} 
	echo $filename; 
	echo "<br/>";
	
	$handle = fopen($filename, 'r'); 
	$data_values = "";
	$result = input_csv($handle); //解析csv 
	$len_result = count($result); 
	if($len_result==0) { 
	
		echo '沒有任何資料！'; 
		exit; 
	} 
	for($i = 1; $i < $len_result; $i++) {//迴圈獲取各欄位值  
		$name = iconv('big-5', 'utf-8', $result[$i][0]); //中文轉碼 
		$account = $result[$i][1]; 
		$password = $result[$i][2]; 
		$membertype = iconv('big-5', 'utf-8', $result[$i][3]);
		$data_values .= "('$name','$account','$password','$membertype'),"; 
	} 
	$data_values = substr($data_values,0,-1); //去掉最後一個逗號 
	echo $data_values;
	fclose($handle);
	mysqli_select_db($db,"ananzoona" );
	$query = mysqli_query($db,"insert into member (姓名,帳號,密碼,種類) values $data_values"); //批量插入資料表中 
	if($query) { 
		echo '匯入成功！'; 
	}
	else{ 
		echo '匯入失敗！'; 
	} 
}
elseif($action=='export') //匯出CSV 
{ 
//匯出處理 
} 

function input_csv($handle) 
{ 
$out = array (); 
$n = 0; 
while ($data = fgetcsv($handle, 10000)) 
{ 
$num = count($data); 
for ($i = 0; $i < $num; $i++) 
{ 
$out[$n][$i] = $data[$i]; 
} 
$n++; 
} 
return $out; 
}
?>
