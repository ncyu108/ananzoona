<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>login</title>
</head>
<body>
<?php
$db = @mysqli_connect(
			'104.198.121.63',
			'root',
			'ananzoona');
if ( !$db ) {
	echo "MySQL伺服器連接錯誤!<br/>";
	exit();
}
else {
	echo "MySQL伺服器連接成功!<br/>";
}
mysqli_select_db($db, "ananzoona" );
	$id = $_POST['UserName'];
	$pw = $_POST['Password'];
	$sql = "SELECT * FROM member where 帳號 = '$id'";
	$result = mysqli_query($db,$sql);
	$row = @mysqli_fetch_row($result);
	if($row[2] == $id && $row[3] == $pw)
	{
        echo '登入成功!';
		//echo '<meta http-equiv=REFRESH CONTENT=1;url=test0730_main.php>';
	}
	else
	{
		
        echo '登入失敗!';
		echo '<meta http-equiv=REFRESH CONTENT=1;url=index.html>';
	}
mysqli_close($db);
?>
</body>
</html>
