<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>login</title>
</head>
<body>

<?php
$db = @mysqli_connect(
			'104.198.121.63',
			'root',
			'ananzoona');
if ( !$db ) {
	echo "MySQL伺服器連接錯誤!<br/>";
	exit();
}
else {
	echo "MySQL伺服器連接成功!<br/>";
}
mysqli_select_db($db, "ananzoona" );
	$id = $_POST['UserName'];
	$pw = $_POST['Password'];
	$sql = "SELECT * FROM member where 帳號 = '$id'";
	$result = mysqli_query($db,$sql);
	$row = @mysqli_fetch_row($result);
	$_SESSION['useraccount']=$row[0];
	
	$_SESSION['UserName']=$row[2];
	
	if($row[2] == $id && $row[3] == $pw && $row[8] == '超級使用者')
	{
        echo '登入成功!';
		header("Location:home.php");
		//echo '<meta http-equiv=REFRESH CONTENT=1;url=home.php>';
	}
	elseif($row[2] == $id && $row[3] == $pw){
		echo '登入成功!';	
		header("Location:home.php");
		//echo '<meta http-equiv=REFRESH CONTENT=1;url=home.php>';
	}
	else
	{	
        echo '登入失敗!';
		header("Location:index.html");
		//echo '<meta http-equiv=REFRESH CONTENT=1;url=index.html>';
	}
mysqli_close($db);
?>
</body>
</html>
