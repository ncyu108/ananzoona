<?php session_start(); ?>
<?php

$lat = $_SESSION["lat"];
$lon = $_SESSION["lon"];
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8" / >
<title>1111</title>
<style type ="text/css">
html{height:100%}
body {height:100%;margin:0px;padding:0px}
#map_canvas{height:100%}
</style>
<script scr = "https://maps.google.com/maps/api/js?sensor=false"></script>
<script scr = "jquery-2.2.0.min.js"></script>
<script>
var map;
$(document).ready(function(){
var myCanvas = document.getElementById("map_canvas");
var myLatlng = new google.maps.Latlng<?php echo $lat; ?>,<?php echo $lon; ?>;
var myOptions={
	zoom:10,
	center:myLatlng,
	mapTypeId:google.maps.MapTypeId.ROADMAP
};
map = new google.maps.Map(myCanvas,myOptions);
var marker = new google.maps.Marker({
	position:myLatlng,
	map:map,
	title:'here'
	});
});
</script>	

</head>
<body>
<div id ="map_canvas" style="width:100%;height:100%"></div>
</body>
</html>