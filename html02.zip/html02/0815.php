<?php session_start(); ?>
<?php
include("connect.php");
mysqli_select_db($db, "ananzoona" );
$year = $_GET['sel'];
$usertype = $_SESSION['usertype'];
$useraccount = $_SESSION['useraccount'];
if(isset($_GET['check']))
{
	$check = $_GET['check'];//value = 1 審核
}
else
{
	$check = 0;
}
if ($usertype == '導師')
{
	$sql = "SELECT * FROM safereport WHERE 學年度 = '$year' && 導師複查 = $check && 導師 = $useraccount order by 學年度 DESC";
	$rows = mysqli_query($db , $sql);//執行SQL查詢
	$num = mysqli_num_rows ($rows);
}
if ($usertype == '教官')
{
	$sql = "SELECT * FROM safereport WHERE 學年度 = '$year' && 導師複查 = 1 && 教官複查 = $check order by 學年度 DESC";
	$rows = mysqli_query($db , $sql);//執行SQL查詢
	$num = mysqli_num_rows ($rows);
}

mysqli_close($db);
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>安全回報</title>
</head>
<center>
<body>
<table border="1">
	<thead>
		<tr>
			<th>學年度</th>
			<th>成員</th>
			<th>房屋資訊</th>
		</tr>
	</thead>
	<tbody>
		<?php
			if($num >0)
			{
				for($i=0 ; $i<$num ; $i++)
				{
					$row = mysqli_fetch_row($rows);
					$name = $row[0];
					echo "<tr>";
					echo "<td>" . $row[20] . "</td>";
					echo "<td>" . $row[2] . "</td>";
					
					echo "<td>"."<a href ='safereport.php?name=$row[1]&year=$row[20]'>$row[1]</a>"."</td>";
					echo "</tr>";
				}
			}
		
			mysqli_free_result($rows);
		?>
		<form>
			<p>學年度
			<select name="sel">
				<?php
					include("connect.php");
					mysqli_select_db($db, "ananzoona" );
					$sql2 = "SELECT 學年度 FROM safereport order by 學年度 DESC";
					$rows2 = mysqli_query($db , $sql2);//執行SQL查詢
					$num2 = mysqli_num_rows ($rows2);
					mysqli_close($db);
					$year = '';
					
					for($i=0;$i<$num2;$i++)
					{
						$row = mysqli_fetch_row($rows2);
						if ($row[0] != $year)
						{
							echo "<option value='". $row[0] ."'>". $row[0];
						}
						$year = $row[0];
					}
				?>
			</select><input type="checkbox" value="1" name="check">審核
				<input type="submit" name="button" id="button" value="搜尋" /></p>
			<input type="submit" name="gohome" value="回首頁" formaction="home.php"/>
		</form>
	</tbody>
</body>
</center>
</html>

