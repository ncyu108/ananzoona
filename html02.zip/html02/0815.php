<?php session_start(); ?>
<?php
include("connect.php");
mysqli_select_db($db, "ananzoona" );
$year = $_GET['sel'];
$usertype = $_SESSION['usertype'];
$useraccount = $_SESSION['useraccount'];
if(isset($_GET['check']))
{
	$check = $_GET['check'];//value = 1 審核
}
else
{
	$check = 0;
}
if ($usertype == '導師')
{
	$sql = "SELECT * FROM safereport WHERE 學年度 = '$year' && 導師複查 = $check && 導師 = $useraccount order by 學年度 DESC";
	$rows = mysqli_query($db, $sql);//執行SQL查詢
	
	$num = mysqli_num_rows ($rows);
	$per = 5; //每頁顯示項目數量
	$pages = ceil($num/$per); //取得不小於值的下一個整數
	if (!isset($_GET["page"]))
	{ //假如$_GET["page"]未設置
        $page=1; //則在此設定起始頁數
    } 
	else 
	{
        $page = intval($_GET["page"]); //確認頁數只能夠是數值資料
    }
	$start = ($page-1)*$per; //每一頁開始的資料序號
	$rows = mysqli_query($db, $sql.' LIMIT '.$start.', '.$per );//執行SQL查詢
}
elseif ($usertype == '教官')
{
	$sql = "SELECT * FROM safereport WHERE 學年度 = '$year' && 導師複查 = 1 && 教官複查 = $check order by 學年度 DESC";
	$rows = mysqli_query($db , $sql);//執行SQL查詢
	$num = mysqli_num_rows ($rows);
	$per = 5; //每頁顯示項目數量
	$pages = ceil($num/$per); //取得不小於值的下一個整數
	
	if (!isset($_GET["page"]))
	{ //假如$_GET["page"]未設置
        $page=1; //則在此設定起始頁數
    } 
	else 
	{
        $page = intval($_GET["page"]); //確認頁數只能夠是數值資料
    }
	$start = ($page-1)*$per; //每一頁開始的資料序號
	$rows = mysqli_query($db, $sql.' LIMIT '.$start.', '.$per );//執行SQL查詢
}
elseif ($usertype == '學生')
{
	$sql = "SELECT * FROM safereport WHERE 學年度 = '$year' && 成員 = $useraccount order by 學年度 DESC";
	$rows = mysqli_query($db , $sql);//執行SQL查詢
	$num = mysqli_num_rows ($rows);
	$per = 5; //每頁顯示項目數量
	$pages = ceil($num/$per); //取得不小於值的下一個整數
	if (!isset($_GET["page"]))
	{ //假如$_GET["page"]未設置
        $page=1; //則在此設定起始頁數
    } 
	else 
	{
        $page = intval($_GET["page"]); //確認頁數只能夠是數值資料
    }
	$start = ($page-1)*$per; //每一頁開始的資料序號
	$rows = mysqli_query($db, $sql.' LIMIT '.$start.', '.$per );//執行SQL查詢
}
else
{
	$sql = "SELECT * FROM safereport";
	$rows = mysqli_query($db , $sql);//執行SQL查詢
	$num = mysqli_num_rows ($rows);
	$per = 5; //每頁顯示項目數量
	$pages = ceil($num/$per); //取得不小於值的下一個整數
	if (!isset($_GET["page"]))
	{ //假如$_GET["page"]未設置
        $page=1; //則在此設定起始頁數
    } 
	else 
	{
        $page = intval($_GET["page"]); //確認頁數只能夠是數值資料
    }
	$start = ($page-1)*$per; //每一頁開始的資料序號
	$rows = mysqli_query($db, $sql.' LIMIT '.$start.', '.$per );//執行SQL查詢
}

mysqli_close($db);
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>學生資訊</title>
<link href="default.css" rel="stylesheet" type="text/css" media="all" />
<link href="fonts.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/style3.css" rel="stylesheet" type="text/css">
</head>
<body>
<div id="header-wrapper">
	<div id="header" class="container">
		<div id="logo">
		<name>歡迎，<?php echo $_SESSION['username'];if($_SESSION['userisonline']==1) {echo '上線中';}?>
		，會員種類：<strong><?php echo $_SESSION['usertype']."</br>";?></strong></name>
		</div>
		<div id="menu">
		<a href="home.php"><img src="images/logo_white.png" width="200" height="70" /></a>
		
			<ul>
				<li><a href="student_manage.php" accesskey="1" >學生管理</a></li>
				<li class="active"><a href="0815.php?sel=<?php 
							include("connect.php");
							mysqli_select_db($db, "ananzoona" );
							$sql2 = "SELECT 學年度 FROM safereport order by 學年度 DESC limit 1";
							$rows2 = mysqli_query($db , $sql2);//執行SQL查詢
							$row = mysqli_fetch_row($rows2);
							echo $row[0];
							?>&check=0" accesskey="2" >安全回報</a></li>
				<li><a href="message_manage.php" accesskey="3" ><?php 
				include("connect.php");
				mysqli_select_db($db, "ananzoona" );

				$account = $_SESSION['useraccount'];
				$sql_message = "SELECT 帳號 FROM member where 帳號 != '$account';";
				$rows_message = mysqli_query($db , $sql_message);//執行SQL查詢
				$num_message = mysqli_num_rows ($rows_message);

				if($num_message >0)
				{
					for($i=0 ; $i<$num_message ; $i++)
					{
						$row_message = mysqli_fetch_row($rows_message);
						$name = $row_message[0];
						$messenge_account = $row_message[0];
						//查詢未讀紀錄//////////////////////////////////////////////////////////////////////////////////////////////////////////
						$select = "SELECT ID FROM message where 接收者帳號 = '$account' && 已讀 = '0';";/////
						$rows2 = mysqli_query($db , $select);//執行SQL查詢//////////////////////////////////////////////////////////////////////
						$num2_message = mysqli_num_rows ($rows2);///////////////////////////////////////////////////////////////////////////////////////
						//查詢未讀紀錄//////////////////////////////////////////////////////////////////////////////////////////////////////////
						$num2_message =+ $num2_message;
					}
					if($num2_message != 0)
					{	
						echo '訊息通知 '.$num2_message;//顯示未讀訊息數量
					}
					else
					{
						echo '訊息通知 0';
					}
				}
				mysqli_free_result($rows_message);
				mysqli_close($db);
			?></a></li>
				<li><a href="member_manage.php" accesskey="4" >個人資訊</a></li>
				<li><a href="member_manager.php" accesskey="5" >帳號管理</a></li>
				<li><a href="suggest.php" accesskey="6" >聯繫我們</a></li>
				
				 <?php 
					$usertype = $_SESSION['usertype'];
					if ($usertype == '超級使用者')
					{ 
						echo '<li><a href="register0913.html" accesskey="7">匯入帳號</a></li>';
					}
				?>
				
				<li><a href="logout.php" accesskey="8" >　登出　</a></li>
			</ul>
			
		</div>
	</div>
</div>
<div class="wrapper">
	<div id="welcome" class="container"></div>
<center>
<body>
<table border="1">
	<thead>
		<tr>
			<th>學年度</th>
			<th>成員</th>
			<th>房屋資訊</th>
		</tr>
	</thead>
	<tbody>
		<?php
			if($num >0)
			{
				for($i=0 ; $i<$per ; $i++)
				{
					$row = mysqli_fetch_row($rows);
					include("connect.php");
					mysqli_select_db($db, "ananzoona" );
					if($row[1] != NULL){
					$sql3 = "SELECT 房屋地址 FROM house WHERE ID = $row[1]";
					$rows3 = mysqli_query($db , $sql3);//執行SQL查詢
					$row3 = mysqli_fetch_row($rows3);
					$name = $row[0];
					echo "<tr>";
					echo "<td>" . $row[13] . "</td>";
					echo "<td>" . $row[2] . "</td>";
					
					echo "<td>"."<a href ='safereport.php?name=$row[1]&year=$row[13]'>$row3[0]</a>"."</td>";
					echo "</tr>";
					mysqli_free_result($rows3);
					}
					mysqli_close($db);
				}
				mysqli_free_result($rows);
			}
		?>
		<form>
			<p>學年度
			<select name="sel">
				<?php
					include("connect.php");
					mysqli_select_db($db, "ananzoona" );
					$sql2 = "SELECT 學年度 FROM safereport order by 學年度 DESC";
					$rows2 = mysqli_query($db , $sql2);//執行SQL查詢
					$num2 = mysqli_num_rows ($rows2);
					mysqli_close($db);
					$year = '';
					
					for($i=0;$i<$num2;$i++)
					{
						$row = mysqli_fetch_row($rows2);
						if ($row[0] != $year)
						{
							echo "<option value='". $row[0] ."'>". $row[0];
						}
						$year = $row[0];
					}
				?>
			</select><input type="checkbox" value="1" name="check" <?php 
			$usertype = $_SESSION['usertype'];
			if ($usertype == '學生')
			{ 
				echo 'hidden=""';
			}
		?>><?php 
			$usertype = $_SESSION['usertype'];
			if ($usertype != '學生')
			{ 
				echo '審核';
			}
		?>
				<input type="submit" name="button" id="button" value="搜尋" /></p>
		</form>
	</tbody>
</table>
<?php
    //分頁頁碼
	include("connect.php");
	mysqli_select_db($db, "ananzoona" );
	$sql2 = "SELECT 學年度 FROM safereport order by 學年度 DESC limit 1";
	$rows2 = mysqli_query($db , $sql2);//執行SQL查詢
	$row = mysqli_fetch_row($rows2);
	
	$sel = '&sel='.$row[0].'&check=0';
	
    echo '共 '.$num.' 筆-在 '.$page.' 頁-共 '.$pages.' 頁';
    echo "<br /><a href=?page=1".$sel.">首頁</a> ";
    echo "第 ";
    for( $i=1 ; $i<=$pages ; $i++ ) {
        if ( $page-3 < $i && $i < $page+3 ) {
			
            echo "<a href=?page=".$i.$sel.">".$i."</a> ";
        }
    } 
    echo " 頁 <a href=?page=".$pages.$sel.">末頁</a><br /><br />";
?>
</center>
</div>
<div id="copyright">
	<p>&copy; 國立嘉義大學資訊管理學系　<br>服務時間：08:00～17:00　聯絡電話：05-2717312　傳真電話：05-2717318<br>24小時緊急聯絡專線：05-2717373　E-Mail：meo@mail.ncyu.edu.tw</br></p>
</div>
</body>
</html>
