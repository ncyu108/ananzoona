<?php session_start(); ?>
<?php
	include("connect.php");
	mysqli_select_db($db, "ananzoona" );
	if (isset($_POST["send"])){
		$pw = $_POST["pw"];
		$account = $_SESSION['useraccount2'];
		echo $account;
		$select = "SELECT * FROM member WHERE 帳號 = '$account';";
		$rows2 = mysqli_query($db,$select);
		$row2 = mysqli_fetch_array($rows2);
		//修改密碼與原本一樣
		if($pw == $row2[3] || $pw == NULL){
			
			//顯示錯誤資訊
			echo '密碼不能跟原本一樣';
			
		}
		else{
			//執行修改程式
			echo '修改成功';
			unset($_SESSION["useraccount2"]);
		}
	//	$sql = "UPDATE member SET 密碼='$pw' WHERE no='$id';";
	//	if(!mysqli_query($db,$sql))
	//		$result="修改記錄失敗</br>".mysqli_error($db);
	//	else header("Location:member_manager.php");
	}
	else {
		$id = $_POST["UserName"];
		$sql = "SELECT * FROM member WHERE 帳號 = '$id'";
		$rows = mysqli_query($db,$sql);
		$row = mysqli_fetch_array($rows);
		$_SESSION['useraccount2']=$row[2];
		$_SESSION['name']=$row[0];
		mysqli_free_result($rows);
		
	}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>帳號管理</title>
</head>
<body>
<h1>編輯</h1></hr>
<ul>

</ul>
</hr>
<form name="delete" method="post" action="">
	<li>帳號: <?php if(isset($_SESSION['useraccount2'])){ 
						echo $_SESSION['useraccount2'];
						}
				?>
	<li>姓名: <?php echo $_SESSION['name'] ?>
	<li>密碼: <input type="password" name="pw" required=""/>
	<hr><input type="submit" name="send" value="確認修改" />
</form>
</body>
</html>