<?php session_start();?>
<?php
	include("connect.php");
	mysqli_select_db($db, "ananzoona" );
	if (isset($_POST["send"])){
		$pw = $_POST["pw"];
		$pw2 = $_POST["pw2"];
		$pw3 = $_POST["pw3"];
		$account = $_SESSION['useraccount'];
		$select = "SELECT * FROM member WHERE 帳號 = '$account';";
		$rows2 = mysqli_query($db,$select);//執行查詢
		$row2 = mysqli_fetch_array($rows2);
		echo $account;
		if($pw != null && $pw2 != null && $pw3 != null)
		{
			//修改密碼與原本一樣
			if (password_verify($pw, $row2[3]))//密碼跟資料庫裡的一樣
			{
				if($pw2 == $pw3)
				{
					if(password_verify($pw2, $row2[3]) || password_verify($pw3, $row2[3]))
					{
						//顯示錯誤資訊
						echo '密碼不能跟原本一樣';
					}
					else
					{
						//執行修改程式
					
						$pwintodb = password_hash($pw3,PASSWORD_BCRYPT);
						$sqlupdate = "UPDATE member SET 密碼 = '$pwintodb' WHERE 帳號 = '".$account."'";
						$rows3 = mysqli_query($db,$sqlupdate);				
						echo '修改成功';
						echo '<script language="javascript">
						alert("修改成功");
						window.location.replace("index.html");
						</script>';
					}					
				}
				else
				{
					echo '新密碼輸入不一樣';
				}
			}
			else
			{
				echo '舊密碼輸入錯誤';
				echo $row2[3];
			}
		}
		else
		{
			echo '<script language="javascript">
					alert("密碼不能為空值");
					window.location.replace("member_manager.php");
				</script>';
		}
		
	}
	else 
	{
		$id = $_SESSION['useraccount']; //取得帳號
		//$_SESSION['account'] = $id;
		$sql = "SELECT * FROM member WHERE 帳號 = '$id'";
		$rows = mysqli_query($db,$sql);
		$row = mysqli_fetch_array($rows);
		$_SESSION['username'] = $row[0];
		mysqli_free_result($rows);	
	}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>密碼管理</title>
<link href="css/website.css" rel="stylesheet" type="text/css">
</head>
<body>
<div id="header" >
	<a href="<?php $userisonline = $_SESSION['userisonline'];if ($userisonline==1){ echo 'home.php';}?>">
		<img src="css/images/ncyu_logo.png" alt="logo" width="400" height="90" class="headerLogo transition" />
	</a>
<div id="content">
  <div id="contentL">
    <div id="sidemenu">
<h1>修改密碼</h1></hr>
<ul>
</ul>
</hr>
<form name="delete" method="post" action="">
	<h3><li>帳號: <?php echo $_SESSION['useraccount'];?>
	<li>姓名: <?php echo $_SESSION['username'];?>
	<li>舊密碼: <input type="password" name="pw"/>
	<li>新密碼: <input type="password" name="pw2"/>
	<li>再次輸入新密碼: <input type="password" name="pw3"/></h3>
	<hr><input type="submit" name="send" value="確認修改" />
	<input type="submit" name="gohome" value="回首頁" formaction="home.php"
	<?php 
		$userisonline = $_SESSION['userisonline'];
		if ($userisonline==0)
		{ 
			echo 'hidden=""';
		}
	?>
	/>
</form>
<div id="contentR">
    <div id="contentMain">
      <p class="subtitle"></p>
    </div>
  </div>
</div>
<div id="footer"></div>
</body>
</html>