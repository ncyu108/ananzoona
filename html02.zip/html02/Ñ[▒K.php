<?php session_start(); ?>
<?PHP
include("hash_pwd.php");
//echo password_hash("rasmuslerdorf",PASSWORD_DEFAULT);
 //echo password_hash("1044625",PASSWORD_ARGON2I);
 $db = @mysqli_connect(
			'104.198.121.63',
			'root',
			'ananzoona');
if ( !$db ) {
	echo "MySQL伺服器連接錯誤!<br/>";
	exit();
}
else {
	echo "MySQL伺服器連接成功!<br/>";
}
mysqli_select_db($db, "ananzoona" );
	$id = $_POST['UserName'];//取得表單輸入帳號
	$pw = $_POST['Password'];
	
	
$sql = "SELECT * FROM member where 帳號 = '$id'";
$result = mysqli_query($db,$sql);
$row = @mysqli_fetch_row($result);
	$_SESSION['password']=$row[3];
	$dbpw = $_SESSION['password'];
	$_SESSION['account'] = $id;
 
 echo $id;
 echo $pw;
 echo $dbpw;

 function compare_pwd($pwd, $pwd_hashed){
        $salt = substr( $pwd_hashed, 0, 32 );
       return $pwd_hashed === hash_pwd($pwd, $salt);
 }
 echo compare_pwd($pw,$dbpw);
 //echo compare_pwd('1044625','7d1e5831ceaccaee36c7480835eff293511e66db2a27a974aa67a5f430f3dd29');
 $comparepw = compare_pwd($pw,$dbpw);//接收比較值，若為TRUE代表密碼輸入正確
 
 //function ipcomparepw($pwd, $pwd_hashed){
 //       $salt = substr( $pwd_hashed, 0, 32 );
 //      return $pwd_hashed === hash_pwd($pwd, $salt);
 //}
 //$comparepw = compare_pwd($pw,$dbpw);
 if($id == $pw){
		echo $id;
		echo $pw;
		echo "<a href='member_manager.php ? id = " .$id."'>跳</a>";
		//header("Location:number_manager.php");
	}else{
		if($row[2] == $id && $comparepw == 1 && $row[8] == '超級使用者')
		{
			echo '登入成功!';
			header("Location:home.php");
			//echo '<meta http-equiv=REFRESH CONTENT=1;url=home.php>';
		}
		elseif($row[2] == $id && $comparepw == 1){
			echo '登入成功!';	
			//echo $pwtest;
			//echo $pw;
			header("Location:home.php");
			//echo '<meta http-equiv=REFRESH CONTENT=1;url=home.php>';
		}
		else
		{	
			echo '登入失敗!';
			//echo $pwchange;
			//header("Location:index.html");
			//echo '<meta http-equiv=REFRESH CONTENT=1;url=index.html>';
		}
	}
 mysqli_close($db);
?>
