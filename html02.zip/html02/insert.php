<?php
//insert.php
if(isset($_POST["subject"]))
{
 include("connect.php");
 $subject = mysqli_real_escape_string($db, $_POST["subject"]);
 $comment = mysqli_real_escape_string($db, $_POST["comment"]);
 $query = "INSERT INTO comments(subject, comment) VALUES ('$subject', '$comment')";
 mysqli_query($db, $query);
}
?>