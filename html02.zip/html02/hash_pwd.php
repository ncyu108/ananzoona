<?php
function hash_pwd($pwd, $salt = false){
        if (!$salt) {
                $salt = md5(mt_rand());
				//$salt = md5();
        }
        return $salt . md5($salt . $pwd);
}
?>