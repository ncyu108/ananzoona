<?php session_start();?>
<?php
	include("connect.php");
	mysqli_select_db($db, "ananzoona" );
	if (isset($_POST["send"]))
	{		
		$mail_address = $_POST["mail_address"];
		$cellphone = $_POST["cellphone"];
		$address1 = $_POST["address1"];
		$address2 = $_POST["address2"];
		$account = $_SESSION['useraccount'];
		
		$select = "SELECT * FROM member WHERE 帳號 = '$account';";
		$rows2 = mysqli_query($db,$select);//執行查詢
		$row2 = mysqli_fetch_array($rows2);
		echo $account;
		
		//執行修改程式
		$sqlupdate = "UPDATE member SET 信箱 = '$mail_address',電話 = '$cellphone',通訊地址 = '$address1',戶籍地址 = '$address2' WHERE 帳號 = '".$account."'";
		$rows3 = mysqli_query($db,$sqlupdate);	
		if($row2[3])
		{
			echo '修改成功';
			echo '<script language="javascript">
			alert("修改成功");
			window.location.replace("home.php");
			</script>';
		}
		else
		{
			echo '修改失敗';
			echo '<script language="javascript">
			alert("修改失敗");
			window.location.replace("member_manage.php");
			</script>';
		}
	}
	else 
	{
		$id = $_SESSION['useraccount']; //取得帳號
		//$_SESSION['account'] = $id;
		$sql = "SELECT * FROM member WHERE 帳號 = '$id'";
		$rows = mysqli_query($db,$sql);
		$row = mysqli_fetch_array($rows);
		$_SESSION['username'] = $row[0];
		$mail_address = $row[1];
		$cellphone = $row[4];
		$address1 = $row[5];
		$address2 = $row[7];
		mysqli_free_result($rows);	
	}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>學生資訊</title>
<link href="default.css" rel="stylesheet" type="text/css" media="all" />
<link href="fonts.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/style3.css" rel="stylesheet" type="text/css">
</head>
<body>
<div id="header-wrapper">
	<div id="header" class="container">
		<div id="logo">
		<name>歡迎，<?php echo $_SESSION['username'];if($_SESSION['userisonline']==1) {echo '上線中';}?>
		，會員種類：<strong><?php echo $_SESSION['usertype']."</br>";?></strong></name>
		</div>
		<div id="menu">
		<a href="home.php"><img src="images/logo_white.png" width="200" height="70" /></a>
		
			<ul>
				<li><a href="student_manage.php" accesskey="1" >學生管理</a></li>
				<li><a href="0815.php?sel=<?php 
							include("connect.php");
							mysqli_select_db($db, "ananzoona" );
							$sql2 = "SELECT 學年度 FROM safereport order by 學年度 DESC limit 1";
							$rows2 = mysqli_query($db , $sql2);//執行SQL查詢
							$row = mysqli_fetch_row($rows2);
							echo $row[0];
							?>&check=0" accesskey="2" >安全回報</a></li>
				<li><a href="message_manage.php" accesskey="3" ><?php 
				include("connect.php");
				mysqli_select_db($db, "ananzoona" );

				$account = $_SESSION['useraccount'];
				$sql = "SELECT 帳號 FROM member where 帳號 != '$account';";
				$rows = mysqli_query($db , $sql);//執行SQL查詢
				$num = mysqli_num_rows ($rows);

				if($num >0)
				{
					for($i=0 ; $i<$num ; $i++)
					{
						$row = mysqli_fetch_row($rows);
						$name = $row[0];
						$messenge_account = $row[0];
						//查詢未讀紀錄//////////////////////////////////////////////////////////////////////////////////////////////////////////
						$select = "SELECT ID FROM message where 接收者帳號 = '$account' && 已讀 = '0';";/////
						$rows2 = mysqli_query($db , $select);//執行SQL查詢//////////////////////////////////////////////////////////////////////
						$num2 = mysqli_num_rows ($rows2);///////////////////////////////////////////////////////////////////////////////////////
						//查詢未讀紀錄//////////////////////////////////////////////////////////////////////////////////////////////////////////
						$num2 =+ $num2;
					}
					if($num2 != 0)
					{	
						echo '訊息通知 '.$num2;//顯示未讀訊息數量
					}
					else
					{
						echo '訊息通知 0';
					}
				}
				mysqli_free_result($rows);
				mysqli_close($db);
			?></a></li>
				<li class="active"><a href="member_manage.php" accesskey="4" >個人資訊</a></li>
				<li><a href="member_manager.php" accesskey="5" >帳號管理</a></li>
				<li><a href="suggest.php" accesskey="6" >聯繫我們</a></li>
				
				 <?php 
					$usertype = $_SESSION['usertype'];
					if ($usertype == '超級使用者')
					{ 
						echo '<li><a href="register.html" accesskey="7">匯入帳號</a></li>';
					}
				?>
				
				<li><a href="logout.php" accesskey="8" >　登出　</a></li>
			</ul>
			
		</div>
	</div>
</div>
<div class="wrapper">
	<div id="welcome" class="container"></div>
<form name="delete" method="post" action="" class="data">
	<li>帳號: <?php echo $_SESSION['useraccount'];?><br><br>
	姓名: <?php echo $_SESSION['username'];?><br><br>
	信箱: <input type="text" style="width:200px;height:5px;padding:10px;font-size:20px;border-radius:5px;color:#DDDDDD" name="mail_address" value="<?php echo $mail_address?>"/><br><br>
	電話: <input type="text" style="width:200px;height:5px;padding:10px;font-size:20px;border-radius:5px;color:#DDDDDD" name="cellphone" value="<?php echo $cellphone?>"/><br><br>
	通訊地址: <input type="text" style="width:200px;height:5px;padding:10px;font-size:20px;border-radius:5px;color:#DDDDDD" name="address1" value="<?php echo $address1?>"/><br><br>
	戶籍地址: <input type="text" style="width:200px;height:5px;padding:10px;font-size:20px;border-radius:5px;color:#DDDDDD" name="address2" value="<?php echo $address2?>"/><br><br>
	種類: <?php echo $_SESSION['usertype'];?></li><br><br>
	<input type="submit" name="send" value="確認修改" style="width:300px;height:50px;padding:10px;font-size:20px;border-radius:5px;color:#FFFFFF;background:#2056ac"/>

</form>
</div>
<div id="copyright">
	<p>&copy; 國立嘉義大學資訊管理學系　<br>服務時間：08:00～17:00　聯絡電話：05-2717312　傳真電話：05-2717318<br>24小時緊急聯絡專線：05-2717373　E-Mail：meo@mail.ncyu.edu.tw</br></p>
</div>
</body>
</html>