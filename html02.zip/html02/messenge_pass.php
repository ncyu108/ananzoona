<!doctype>
<html>
<head>
<meta charset="utf-8"/>
<title>留言</title>
</head>
<body>
<form action="message_transfer.php" method="post">
	<table>
		<tr>
			<td>姓名：
			<?php
				session_start();
				echo $_SESSION["useraccount"]; 
			?>
			</td>
		</tr>
		<tr>
			<td>留言：</td>
			<td>
				<textarea name="Message" row="4" cols="30"></textarea>
			</td>
		</tr>
	</table>
	<input type="submit" name="Send" value="送出留言">
	<input type="reset" name="Reset" value="重設欄位">
</form>
</body>
</html>