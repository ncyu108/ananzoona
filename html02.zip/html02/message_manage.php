<?php
include("connect.php");
mysqli_select_db($db, "ananzoona" );
session_start();

$account = $_SESSION['useraccount'];

$sql = "SELECT * FROM member where 帳號 != '$account';";
$rows = mysqli_query($db , $sql);//執行SQL查詢
$num = mysqli_num_rows ($rows);
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>選擇接收訊息的人</title>
<link href="css/style3.css" rel="stylesheet" type="text/css">
<link href="css/back.css" rel="stylesheet" type="text/css">
</head>
<center>
<body>
<img src="css/images/logo.png" width="500" height="100" />
<table border="1">
	<thead>
		<tr>
			<th>姓名</th>
			<th>學號</th>
			<th>未讀訊息</th>
			<th>傳送訊息</th>
		</tr>
	</thead>
	<tbody>
		<?php
		if($num >0){
			for($i=0 ; $i<$num ; $i++){
				$row = mysqli_fetch_row($rows);
					$name = $row[0];
					$messenge_account = $row[2];
					echo "<tr>";
					echo "<td>" . $row[0] . "</td>";
					echo "<td>" . $row[2] . "</td>";
					//查詢未讀紀錄//////////////////////////////////////////////////////////////////////////////////////////////////////////
					$select = "SELECT * FROM message where 接收者帳號 = '$account' && 傳送者帳號 = '$messenge_account' && 已讀 = '0';";/////
					$rows2 = mysqli_query($db , $select);//執行SQL查詢//////////////////////////////////////////////////////////////////////
					$num2 = mysqli_num_rows ($rows2);///////////////////////////////////////////////////////////////////////////////////////
					//查詢未讀紀錄//////////////////////////////////////////////////////////////////////////////////////////////////////////
					echo "<td>" . $num2 . "</td>";//顯示未讀訊息數量
					echo "<td>"."<a href ='messenge_pass.php?name=" . $row[0] . "'>傳送訊息</a>"."</td>";
					echo "</tr>";
			}
		}
		
		mysqli_free_result($rows);
		mysqli_close($db);
		?>
	</tbody>
	<form>
	<br><a href="home.php"><img src="css/images/back.png" alt="back" width="100" height="50" /></a></br>
		<!--<input type="submit" name="gohome" value="回首頁" formaction="home.php"/>-->
	</form>
</body>
</center>
</html>

