<?php
// 開啟XML檔案，NODE
$dom = new DOMDocument("1.0");
$node = $dom->createElement("markers");
$parnode = $dom->appendChild($node);
//連線
$db=mysqli_connect ('104.198.121.63','root','ananzoona');
mysqli_select_db($db,"ananzoona" );
$sql = "SELECT * FROM maptest ";
$rows = mysqli_query($db , $sql);

$sql2 = "SELECT * FROM maptest";
$rows2 = mysqli_query($db , $sql2);


header("Content-type: text/xml");
//讀取到XML檔

while ($row = mysqli_fetch_assoc($rows2)){
  // Add to XML document node
  $node = $dom->createElement("marker");
  $newnode = $parnode->appendChild($node);
  $newnode->setAttribute("id",$row['ID']);
  $newnode->setAttribute("name",$row['name']);
  $newnode->setAttribute("address", $row['address']);
  $newnode->setAttribute("lat", $row['lat']);
  $newnode->setAttribute("lng", $row['lng']);
  $newnode->setAttribute("type", $row['type']);
}
/*
while ($row = mysqli_fetch_assoc($rows)){
  // Add to XML document node
  $node = $dom->createElement("marker");
  $newnode = $parnode->appendChild($node);
  $newnode->setAttribute("id",$row['ID']);
  $newnode->setAttribute("name",$row['name']);
  $newnode->setAttribute("address", $row['address']);
  $newnode->setAttribute("lat", $row['lat']);
  $newnode->setAttribute("lng", $row['lng']);
  $newnode->setAttribute("type", $row['type']);
}*/

echo $dom->saveXML();
/*
$db=mysqli_connect ('104.198.121.63','root','ananzoona');
mysqli_select_db($db,"ananzoona" );
$sql = "SELECT * FROM maptest ";
$rows = mysqli_query($db , $sql);
$num = mysqli_num_rows($rows);
mysqli_close($db);
while($row = mysqli_fetch_array($rows)){
	$lat = $row["lat"];
	$lng = $row["lng"];
	
	}
	echo $lng;
	*/
?>
