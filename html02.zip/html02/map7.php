<?php
$db=mysqli_connect ('104.198.121.63','root','ananzoona');
mysqli_select_db($db,"ananzoona" );
$sql = "SELECT * FROM maptest ";
$rows = mysqli_query($db , $sql);
$num = mysqli_num_rows($rows);
mysqli_close($db);
while($row = mysqli_fetch_array($rows)){
	$lat = $row["lat"];
	$lng = $row["lng"];
	echo $lng;
	}
	
?>

<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="initial-scale=1.0, user-scalable=no">
    <meta charset="utf-8">
    <title>Marker Clustering</title>
    <style>
      /* Always set the map height explicitly to define the size of the div
       * element that contains the map. */
      #map {
        height: 50%;
		width : 50%
      }
      /* Optional: Makes the sample page fill the window. */
      html, body {
        height: 100%;
        margin: 0;
        padding: 0;
      }
    </style>
  </head>
  <body>
    <div id="map"></div>
    <script>

      function initMap() {

        var map = new google.maps.Map(document.getElementById('map'), {
          zoom: 12,
          center: {lat: 23.463408, lng: 120.441886}
        });

        // Create an array of alphabetical characters used to label the markers.
        var labels = '';

        // Add some markers to the map.
        // Note: The code uses the JavaScript Array.prototype.map() method to
        // create an array of markers based on a given "locations" array.
        // The map() method here has nothing to do with the Google Maps API.
        var markers = locations.map(function(location, i) {
          return new google.maps.Marker({
            position: location,
            label: labels[i % labels.length]
          });
        });

        // Add a marker clusterer to manage the markers.
        var markerCluster = new MarkerClusterer(map, markers,
            {imagePath: 'https://developers.google.com/maps/documentation/javascript/examples/markerclusterer/m'});
      }
	 
      var locations = [
		
		
		/*{lat:<?php echo $lat ?>, lng:<?php echo $lng ?>}*/
		
	  {lat:23.454163, lng: 120.452993},
	  {lat:23.454163, lng: 120.453993},
	  {lat:23.454163, lng: 120.454993},
	  {lat:23.454163, lng: 120.456993},
	  {lat:23.454163, lng: 120.455993},
	  {lat:23.454163, lng: 120.457993},
	  {lat:23.454163, lng: 120.458993}
	  
      ]
    </script>
    <script src="https://developers.google.com/maps/documentation/javascript/examples/markerclusterer/markerclusterer.js">
    </script>
    <script async defer
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA1ZQFXsgrWJznTnsS5Enys-KeaYxmmj8Y&callback=initMap">
    </script>
  </body>
</html>
