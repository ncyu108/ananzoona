<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>login</title>
</head>
<body>

<?php
session_start();
include("connect.php");
mysqli_select_db($db, "ananzoona" );

$account = $_SESSION["useraccount"];
echo $account;
$name = $_SESSION["username"];
$text = $_POST["Message"];
$messenge_account = $_SESSION['messenge_account'];
$messenge_member = $_SESSION['messenge_member'];


$query = mysqli_query($db,"insert into message (接收者帳號,接收者姓名,傳送者帳號,傳送者姓名,訊息內容) values ('$messenge_account','$messenge_member','$account','$name','$text')");
if ($query) {
	
	$result = "上傳成功";
    echo '上傳成功!';
	header("Location:messenge_pass.php?name=$messenge_member");
	
}
else{ 

	$result = "上傳失敗<br/>".mysqli_error($db);
    echo $result;
	
}
mysqli_close($db);
unset($_SESSION['messenge_account']);
unset($_SESSION['messenge_member']);
?>
</body>
</html>