<?php 
$type = $_POST['type'];
echo $type;
//$id = $_POST['account'];
//$password = $_POST['password'];//輸入的密碼
//$password2 = '$2y$10$SA6LAckpzE9CK1YEQwOlY.Z8fXvrIRv8MTt8EbNcw9t0W7FfmxTFi';
//$password2 = password_hash($password,PASSWORD_BCRYPT);//寫入資料庫的密碼
//password_hash($password(輸入的密碼),PASSWORD_BCRYPT(加密的函數))加密用
//password_verify($password(輸入的密碼), $password2(資料庫讀出來的密碼))解密用

//if (password_verify($password, $password2)) 
//{
//    echo $password;
//	echo ' Password is valid! ';
//	echo $password2;
//} 
//else 
//{
//    echo 'Invalid password.';
//}
//include("connect.php");
//mysqli_select_db($db,"ananzoona" );
//$query = mysqli_query($db,"insert into member (姓名,帳號,密碼,種類) values ('test0816','$id','$password2','學生')");
//$query = mysqli_query($db,"SELECT * FROM member where 帳號 = '$id';");
//$row = @mysqli_fetch_row($query);
//密碼
//$password3=$row[3];
//if($query) {
	
//		if (password_verify($password, $password3)){
			
//			echo '登入成功';
			
//		}
//		else {
//			echo '登入失敗';
//		}
//	}
//	else{ 
//		echo '匯入失敗！'; 
//	} 
//mysqli_close($db);
?>