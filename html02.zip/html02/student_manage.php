<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>學生資訊</title>
<link href="css/style3.css" rel="stylesheet" type="text/css">
<link href="css/back.css" rel="stylesheet" type="text/css">
</head>
<center>
<body>
<img src="css/images/logo.png" width="500" height="100" />
<table border="1">
	<thead>
		<tr>
			<th>姓名</th>
			<th>學號</th>
		</tr>
	</thead>
	<tbody>
<?php session_start(); ?>
<?php
include("connect.php");
mysqli_select_db($db, "ananzoona" );
$usertype = $_SESSION['usertype'];
$useraccount = $_SESSION['useraccount'];
if ($usertype == '導師')
{
	$sql = "SELECT * FROM member WHERE 種類 = '學生' && 導師 = $useraccount order by 帳號 DESC";
	$rows = mysqli_query($db , $sql);//執行SQL查詢
	$num = mysqli_num_rows ($rows);
	
	if($num >0)
			{
				for($i=0 ; $i<$num ; $i++)
				{
					$row = mysqli_fetch_row($rows);
					echo "<tr>";
					echo "<td>"."<a href ='student_safereport.php?account=$row[2]'>$row[0]</a>"."</td>";
					echo "<td>" . $row[2] . "</td>";
					echo "</tr>";
					//mysqli_free_result($rows2);
					//mysqli_close($db);
				}
				mysqli_free_result($rows);
			}
}
mysqli_close($db);
?>
</tbody>
	<form>
	<br><a href="home.php"><img src="css/images/back.png" alt="back" width="100" height="50" /></a></br>
		<!--<input type="submit" name="gohome" value="回首頁" formaction="home.php"/>-->
	</form>
</body>
</center>
</html>