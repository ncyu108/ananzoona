<?php session_start(); ?>
<?php
	include("connect.php");
	$name = $_GET["name"];
	$year = $_GET["year"];
	$usertype = $_SESSION['usertype'];
	mysqli_select_db($db, "ananzoona" );
	if (isset($_POST["send"]))
	{
		if($usertype == '導師')
		{
			$sqlupdate = "UPDATE safereport SET 導師複查 = 1 WHERE 房屋資訊 like $name && 學年度 = $year;";
			$rows3 = mysqli_query($db,$sqlupdate);
			echo '<script language="javascript">
			alert("導師已複查");
			</script>';
		}
		elseif($usertype == '教官')
		{
			$sqlupdate = "UPDATE safereport SET 教官複查 = 1 WHERE 房屋資訊 like $name && 學年度 = $year;";
			$rows3 = mysqli_query($db,$sqlupdate);
			echo '<script language="javascript">
			alert("教官已複查");
			</script>';
		}
		elseif($usertype == '學生')
		{
			echo '<script language="javascript">
			alert("學生不能修改R");
			</script>';
		}
		
		
		$sql = "SELECT * FROM safereport WHERE 房屋資訊 like $name && 學年度 = $year;";
		$rows = mysqli_query($db , $sql);//執行SQL查詢
		$row = mysqli_fetch_row($rows);
		$ps = $row[0];
		$house = $row[1];
		$member = $row[2];
		$access = $row[3];
		$light = $row[4];
		$fire_extinguisher = $row[5];
		$alart = $row[6];
		$way = $row[7];
		$got_the_way = $row[8];
		$wtf = $row[9];
		$type = $row[10];
		$place = $row[11];
		$ID = $row[12];
		$year = $row[13];
		$teacher_check = $row[14];
		$instructor_check = $row[15];
		$teacher = $row[16];
	}
	else
	{
		$sql = "SELECT * FROM safereport WHERE 房屋資訊 like $name && 學年度 = $year;";
		$rows = mysqli_query($db , $sql);//執行SQL查詢
		$row = mysqli_fetch_row($rows);
		$ps = $row[0];
		$house = $row[1];
		$member = $row[2];
		$access = $row[3];
		$light = $row[4];
		$fire_extinguisher = $row[5];
		$alart = $row[6];
		$way = $row[7];
		$got_the_way = $row[8];
		$wtf = $row[9];
		$type = $row[10];
		$place = $row[11];
		$ID = $row[12];
		$year = $row[13];
		$teacher_check = $row[14];
		$instructor_check = $row[15];
		$teacher = $row[16];
		mysqli_close($db);
	}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>安全回報</title>
<link href="default.css" rel="stylesheet" type="text/css" media="all" />
<link href="fonts.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/style3.css" rel="stylesheet" type="text/css">
</head>
<body>
<div id="header-wrapper">
	<div id="header" class="container">
		<div id="logo">
		<name>歡迎，<?php echo $_SESSION['username'];if($_SESSION['userisonline']==1) {echo '上線中';}?>
		，會員種類：<strong><?php echo $_SESSION['usertype']."</br>";?></strong></name>
		</div>
		<div id="menu">
		<a href="home.php"><img src="images/logo_white.png" width="200" height="70" /></a>
		
			<ul>
				<li><a href="student_manage.php" accesskey="1" >學生管理</a></li>
				<li class="active"><a href="0815.php?sel=<?php 
							include("connect.php");
							mysqli_select_db($db, "ananzoona" );
							$sql2 = "SELECT 學年度 FROM safereport order by 學年度 DESC limit 1";
							$rows2 = mysqli_query($db , $sql2);//執行SQL查詢
							$row = mysqli_fetch_row($rows2);
							echo $row[0];
							?>&check=0" accesskey="2" >安全回報</a></li>
				<li><a href="message_manage.php" accesskey="3" ><?php 
				include("connect.php");
				mysqli_select_db($db, "ananzoona" );

				$account = $_SESSION['useraccount'];
				$sql = "SELECT 帳號 FROM member where 帳號 != '$account';";
				$rows = mysqli_query($db , $sql);//執行SQL查詢
				$num = mysqli_num_rows ($rows);

				if($num >0)
				{
					for($i=0 ; $i<$num ; $i++)
					{
						$row = mysqli_fetch_row($rows);
						$name = $row[0];
						$messenge_account = $row[0];
						//查詢未讀紀錄//////////////////////////////////////////////////////////////////////////////////////////////////////////
						$select = "SELECT ID FROM message where 接收者帳號 = '$account' && 已讀 = '0';";/////
						$rows2 = mysqli_query($db , $select);//執行SQL查詢//////////////////////////////////////////////////////////////////////
						$num2 = mysqli_num_rows ($rows2);///////////////////////////////////////////////////////////////////////////////////////
						//查詢未讀紀錄//////////////////////////////////////////////////////////////////////////////////////////////////////////
						$num2 =+ $num2;
					}
					if($num2 != 0)
					{	
						echo '訊息通知 '.$num2;//顯示未讀訊息數量
					}
					else
					{
						echo '訊息通知 0';
					}
				}
				mysqli_free_result($rows);
				mysqli_close($db);
			?></a></li>
				<li><a href="member_manage.php" accesskey="4" >個人資訊</a></li>
				<li><a href="member_manager.php" accesskey="5" >帳號管理</a></li>
				<li><a href="suggest.php" accesskey="6" >聯繫我們</a></li>
				
				 <?php 
					$usertype = $_SESSION['usertype'];
					if ($usertype == '超級使用者')
					{ 
						echo '<li><a href="register0913.html" accesskey="7">匯入帳號</a></li>';
					}
				?>
				
				<li><a href="logout.php" accesskey="8" >　登出　</a></li>
			</ul>
			
		</div>
	</div>
</div>
<div class="wrapper">
	<div id="welcome" class="container"></div>
<form name="delete" method="post" action="" class="data">
	<div class="la">房屋資訊: <?php echo $house;?><br><br>
	學年度: <?php echo $year;?><br><br>
	成員: <?php echo $member?><br><br>
<?php 
		if ($_SESSION['usertype'] == '導師')
		{ 
			echo '導師複查:';
			if($row[14] == 0){echo '尚未審查';}
			else{echo '已審查';}
		}
		elseif ($_SESSION['usertype'] == '教官')
		{ 
			echo '教官複查:';
			if($row[22] == 0){echo '尚未審查';}
			else{echo '已審查';}
		}		
	?><br><br>
	<?php
	if($access==1)
	{
		echo '租屋處是否有共同門禁管制:<input type="checkbox" name="check" disabled="" checked=""/>';
	}
	else
	{
		echo '租屋處是否有共同門禁管制:<input type="checkbox" name="check" disabled=""/>';
	}
	?><br><br>
	<?php
	if($light==1)
	{
		echo '租屋處內或週邊停車場是否有照明設施:<input type="checkbox" name="check" disabled="" checked=""/>';
	}
	else
	{
		echo '租屋處內或週邊停車場是否有照明設施:<input type="checkbox" name="check" disabled=""/>';
	}
	?><br><br>
	<?php
	if($fire_extinguisher==1)
	{
		echo '是否設有滅火器:<input type="checkbox" name="check" disabled="" checked=""/>';
	}
	else
	{
		echo '是否設有滅火器:<input type="checkbox" name="check" disabled=""/>';
	}
	?><br><br>
	<?php
	if($alart==1)
	{
		echo '是否有火警警報器或獨立型偵煙偵測器:<input type="checkbox" name="check" disabled="" checked=""/>';
	}
	else
	{
		echo '是否有火警警報器或獨立型偵煙偵測器:<input type="checkbox" name="check" disabled=""/>';
	}
	?><br><br>
	<?php
	if($way==1)
	{
		echo '逃生路線是否暢通並標示清楚:<input type="checkbox" name="check" disabled="" checked=""/>';
	}
	else
	{
		echo '逃生路線是否暢通並標示清楚:<input type="checkbox" name="check" disabled=""/>';
	}
	?><br><br>
	<?php
	if($got_the_way==1)
	{
		echo '是否知道逃生路線:<input type="checkbox" name="check" disabled="" checked=""/>';
	}
	else
	{
		echo '是否知道逃生路線:<input type="checkbox" name="check" disabled=""/>';
	}
	?><br><br>
	<?php
	if($wtf==1)
	{
		echo '請依學校校外宿舍使用熱水器安全診斷表評核:<input type="checkbox" name="check" disabled="" checked=""/>';
	}
	else
	{
		echo '請依學校校外宿舍使用熱水器安全診斷表評核:<input type="checkbox" name="check" disabled=""/>';
	}
	?></div>
	<body>
	<?php
	//0911新增查詢安全回報圖片 
		include("connect.php");
		mysqli_select_db($db, "ananzoona" );
		$sql_select = "SELECT * FROM picture WHERE 所屬回報單ID = $ID;";
		$rows4 = mysqli_query($db , $sql_select);//執行SQL查詢
		$num3 = mysqli_num_rows ($rows4);
		if($num3 >0)
			{
				for($i=0 ; $i<$num3 ; $i++)
				{
					$row3 = mysqli_fetch_row($rows4);
					$name = $row3[1];
					$way = $row3[2];
					echo '<img src="'.$way.$name.'" width="1200" height="500"/>';
				}
				mysqli_free_result($rows4);
			}
		mysqli_close($db);
	?>
	</body>
	<input type="submit" name="send" value="確認審核" <?php 
		if ($_SESSION['usertype'] == '導師')
		{ 
			if ($row[14]==1)
			{ 
				echo 'hidden=""';
			} 
		}
		elseif ($_SESSION['usertype'] == '教官')
		{ 
			if ($row[15]==1)
			{ 
				echo 'hidden=""';
			}
		}	
		
	?>/>
</form>

	<!--<form>
		<a href="0815.php?sel=<?php/* 
							include("connect.php");
							mysqli_select_db($db, "ananzoona" );
							$sql2 = "SELECT 學年度 FROM safereport order by 學年度 DESC limit 1";
							$rows2 = mysqli_query($db , $sql2);//執行SQL查詢
							$row = mysqli_fetch_row($rows2);
							echo $row[0];
							*/?>" method="post"><img src="css/images/works_btn.png" alt="安全回報管理" width="30" height="20" class="transition" /></a>
	</form>-->
	</tbody>
</div>
<div id="copyright">
	<p>&copy; 國立嘉義大學資訊管理學系　<br>服務時間：08:00～17:00　聯絡電話：05-2717312　傳真電話：05-2717318<br>24小時緊急聯絡專線：05-2717373　E-Mail：meo@mail.ncyu.edu.tw</br></p>
</div>
</body>
</html>