<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>picture</title>
</head>
<center>
<body>
<table border="1">
	<thead>
		<tr>
			<th>備註</th>
			<th>成員</th>
			<th>PASSWORD</th>
			<th>safereport</th>
		</tr>
	</thead>
	<tbody>
<?php
	include("connect.php");
	$name = $_GET["name"];
	mysqli_select_db($db, "ananzoona" );
	$sql = "SELECT * FROM safereport WHERE 成員 like '$name';";
	$rows = mysqli_query($db , $sql);//執行SQL查詢
	$num = mysqli_num_rows ($rows);
	
		if($num >0){
			for($i=0 ; $i<$num ; $i++){
				$row = mysqli_fetch_row($rows);
					echo "<tr>";
					echo "<td>" . $row[0] . "</td>";
					echo "<td>" . $row[2] . "</td>";
					echo "<td>" . $row[3] . "</td>";
					//echo "</tr>";
			}
		}
mysqli_close($db);
?>
	</tbody>
</body>
</center>
</html>