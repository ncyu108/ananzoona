<?php session_start(); ?>
<?php
	include("connect.php");
	$name = $_GET["name"];
	$year = $_GET["year"];
	$usertype = $_SESSION['usertype'];
	mysqli_select_db($db, "ananzoona" );
	if (isset($_POST["send"]))
	{
		if($usertype == '導師')
		{
			$sqlupdate = "UPDATE safereport SET 導師複查 = 1 WHERE 房屋資訊 like $name && 學年度 = $year;";
			$rows3 = mysqli_query($db,$sqlupdate);
			echo '<script language="javascript">
			alert("導師已複查");
			</script>';
		}
		elseif($usertype == '教官')
		{
			$sqlupdate = "UPDATE safereport SET 教官複查 = 1 WHERE 房屋資訊 like $name && 學年度 = $year;";
			$rows3 = mysqli_query($db,$sqlupdate);
			echo '<script language="javascript">
			alert("教官已複查");
			</script>';
		}
		elseif($usertype == '學生')
		{
			echo '<script language="javascript">
			alert("學生不能修改R");
			</script>';
		}
		
		
		$sql = "SELECT * FROM safereport WHERE 房屋資訊 like $name && 學年度 = $year;";
		$rows = mysqli_query($db , $sql);//執行SQL查詢
		$row = mysqli_fetch_row($rows);
	}
	else
	{
		$sql = "SELECT * FROM safereport WHERE 房屋資訊 like $name && 學年度 = $year;";
		$rows = mysqli_query($db , $sql);//執行SQL查詢
		$row = mysqli_fetch_row($rows);
		mysqli_close($db);
	}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>picture</title>
</head>
<center>
<body>
<h1>編輯個人資料</h1></hr>
<ul>
</ul>
</hr>
<form name="delete" method="post" action="">
	<h3><li>房屋資訊: <?php echo $row[1];?></li>
	<li>學年度: <?php echo $row[20];?></li>
	<li>成員: <?php echo $row[2]?></li>
	<li <?php 
			$usertype = $_SESSION['usertype'];
			if ($usertype == '學生')
			{ 
				echo 'hidden=""';
			}
		?>><?php 
		if ($_SESSION['usertype'] == '導師')
		{ 
			echo '導師複查:';
			if($row[21] == 0){echo '尚未審查';}
			else{echo '已審查';}
		}
		elseif ($_SESSION['usertype'] == '教官')
		{ 
			echo '教官複查:';
			if($row[22] == 0){echo '尚未審查';}
			else{echo '已審查';}
		}		
	?></li>
	<hr><input type="submit" name="send" value="確認審核" <?php 
		if ($_SESSION['usertype'] == '導師')
		{ 
			if ($row[21]==1)
			{ 
				echo 'hidden=""';
			} 
		}
		elseif ($_SESSION['usertype'] == '教官')
		{ 
			if ($row[22]==1)
			{ 
				echo 'hidden=""';
			}
		}	
		
	?>/>
	<input type="submit" name="gohome" value="回首頁" formaction="home.php"/>
</form>

	<form>
		<a href="0815.php?sel=<?php 
							include("connect.php");
							mysqli_select_db($db, "ananzoona" );
							$sql2 = "SELECT 學年度 FROM safereport order by 學年度 DESC limit 1";
							$rows2 = mysqli_query($db , $sql2);//執行SQL查詢
							$row = mysqli_fetch_row($rows2);
							echo $row[0];
							?>" method="post"><img src="css/images/works_btn.png" alt="安全回報管理" width="30" height="20" class="transition" /></a>
	</form>
	</tbody>
</body>
</center>
</html>