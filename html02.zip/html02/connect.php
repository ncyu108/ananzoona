<?php
$db = @mysqli_connect(
			'104.198.121.63',
			'root',
			'ananzoona');
if ( !$db ) {
	echo "MySQL伺服器連接錯誤!<br/>";
	exit();
}
else {
	echo "MySQL伺服器連接成功!<br/>";
}
mysqli_close($db);
return $db;
?>