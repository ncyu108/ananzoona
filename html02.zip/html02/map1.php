<?php session_start(); ?>
<?php
if (isset($_POST["send"])){
	$lat = $_POST["lat"];
	$lon = $_POST["lon"];
	if (!empty($lat)&& !empty($lon)){
		$para = "lat" . $lat . "&lon" . $lon;
		header ("Location: map2.php?" . $para);
	}
	else{
		$result = "錯";
	}
}
else $result = "輸入阿";
$_SESSION['lat'];
$_SESSION['lon'];
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8" / >
<title>0000</title>
</head>
<body>
<form method="post" action="">
	<p>緯度:
	<input type ="text" name ="lat" id = "lat" value = "37.49"/></p>
	<p>經度:
	<input type ="text" name ="lon" id = "lon" value = "-122.29"/></p>
	<input type = "submit" name ="send" value ="顯示地圖"/>
</form><hr/>
<?php echo $result ?>	
</body>
</html>