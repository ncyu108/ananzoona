package com.example.four.member;

import android.app.AlertDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.os.StrictMode;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;

public class AddBackgrouneWorker extends AsyncTask<String,Void,String> {
    Context context;
    AlertDialog alertDialog;
    public AsyncResponse delegate ;
    public AddBackgrouneWorker(AsyncResponse delegate){
        delegate = delegate;
    }
    public interface AsyncResponse {
        void processFinish(String output);
    }
    @Override
    protected String doInBackground(String... params) {
        String Leader = params[0];
        String name1 = params[1];
        String register_url = "http://10.3.204.7/test.php";
        //   String name = nameTxt.getText().toString();
        String total=params[2];
        String year=params[3];
        String Idd=params[4];
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        String result="";
        try {
            String user_name = name1;
            String leader =Leader;
            String idd =Idd;

            URL url = new URL(register_url);
            HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
            httpURLConnection.setRequestMethod("POST");
            httpURLConnection.setDoOutput(true);
            httpURLConnection.setDoInput(true);
            OutputStream outputStream = httpURLConnection.getOutputStream();
            BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
            String post_data = URLEncoder.encode("leader", "UTF-8") + "=" + URLEncoder.encode(leader, "UTF-8") + "&"
                    + URLEncoder.encode("user_name", "UTF-8") + "=" + URLEncoder.encode(user_name, "UTF-8")+ "&"
                    + URLEncoder.encode("total", "UTF-8") + "=" + URLEncoder.encode(total, "UTF-8")+ "&"
                    + URLEncoder.encode("year", "UTF-8") + "=" + URLEncoder.encode(year, "UTF-8")+"&"
                    + URLEncoder.encode("idd", "UTF-8") + "=" + URLEncoder.encode(idd, "UTF-8");
            bufferedWriter.write(post_data);
            bufferedWriter.flush();
            bufferedWriter.close();
            outputStream.close();
            InputStream inputStream = httpURLConnection.getInputStream();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "iso-8859-1"));
            String line = "";
            while ((line = bufferedReader.readLine()) != null) {
                result += line;
            }
            bufferedReader.close();
            inputStream.close();
            httpURLConnection.disconnect();
            return result;
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


        return result;
    }
    @Override
    protected void onPostExecute(String result){
        if(result.equals("success")) {
            delegate.processFinish(result);
        }
        else{
            delegate.processFinish(result);
        }
    }
}
