package com.example.four.member;

import android.app.Application;

public class Global extends Application {
    public String UserNum ="";
    public String UserPass ="";
}
