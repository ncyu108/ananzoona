package com.example.four.member;

import android.os.Bundle;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;


public class ToPersonal extends AppCompatActivity{
    EditText Name;
    EditText Phone;
    EditText Address;
    EditText Email;
    ArrayAdapter<String> adapter;
    String readperson_url = "http://10.3.204.7/personaldata.php";
    InputStream is = null;
    String line = null;
    String result =null;
    String[] data;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_to_personal);
       Name=(EditText)findViewById(R.id.edName);
       Phone=(EditText)findViewById(R.id.edPhone);
       Address=(EditText)findViewById(R.id.edAddress);
       Email=(EditText)findViewById(R.id.edEmail);
        Global global =(Global) getApplicationContext().getApplicationContext();
        String UserNum=global.UserNum;
      StrictMode.setThreadPolicy((new StrictMode.ThreadPolicy.Builder().permitNetwork().build()));
      getData("1",UserNum);
       adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,data);
       Name.setText(data[0]);
        getData("2",UserNum);
        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,data);
        Phone.setText(data[0]);
        getData("3",UserNum);
        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,data);
        Address.setText(data[0]);
        getData("4",UserNum);
        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,data);
        Email.setText(data[0]);
    }
    private void getData(String a,String b){
        try {
            String user_name = b;
            URL url = new URL(readperson_url);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            con.setDoOutput(true);
            con.setDoInput(true);
            OutputStream outputStream = con.getOutputStream();
            BufferedWriter bufferedWriter =new BufferedWriter(new OutputStreamWriter(outputStream,"UTF-8"));
            String post_data = URLEncoder.encode("user_name","UTF-8")+"=" + URLEncoder.encode(user_name,"UTF-8");
            bufferedWriter.write(post_data);
            bufferedWriter.flush();
            bufferedWriter.close();
            outputStream.close();
            is = new BufferedInputStream(con.getInputStream());
        }catch (Exception e){
            e.printStackTrace();
        }
        try {
            BufferedReader br =new BufferedReader(new InputStreamReader(is));
            StringBuilder sb =new StringBuilder();
           while ((line=br.readLine())!=null){
                sb.append(line+"\n");

            }
            is.close();
            result=sb.toString();
        }catch (Exception e){
           e.printStackTrace();
        }
       try{
            JSONArray ja=new JSONArray(result);
            JSONObject jo = null;
          data = new String[ja.length()];
           for(int i=0;i<ja.length();i++){
               jo=ja.getJSONObject(i);
               if(a=="1") {
                   data[i] = jo.getString("username");
               }
               if(a=="2"){
                   data[i] = jo.getString("phonenumber");
               }
               if(a=="3"){
                   data[i] = jo.getString("address");
               }
               if(a=="4"){
                   data[i] = jo.getString("email");
               }
           }
       }catch (Exception e){
        e.printStackTrace();
        }
        }
    public void Recive(View view){
        Name.setFocusableInTouchMode(true);
        Name.setFocusable(true);
        Name.requestFocus();
        Phone.setFocusableInTouchMode(true);
        Phone.setFocusable(true);
        Phone.requestFocus();
        Address.setFocusableInTouchMode(true);
        Address.setFocusable(true);
        Address.requestFocus();
        Email.setFocusableInTouchMode(true);
        Email.setFocusable(true);
        Email.requestFocus();
        //  Complie.setVisibility(View.VISIBLE); //顯示
        // Complie.setVisibility(View.VISIBLE); //顯示
        // Revise.setVisibility(View.INVISIBLE); // 隱藏
        // Revise.setVisibility(View.INVISIBLE); // 隱藏
    }
    public void Complie(View view){
        String str_name=Name.getText().toString();
        String str_phone=Phone.getText().toString();
        String str_address=Address.getText().toString();
        String str_email=Email.getText().toString();
        String type = "register";
        BackgroundWorker backgroundWorker = new BackgroundWorker(this);
        backgroundWorker.execute(type,str_name,str_phone,str_address,str_email);
    }
}
