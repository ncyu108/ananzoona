package com.example.four.member;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class InputNewPass extends AppCompatActivity {
    EditText PasswordEt,NewPassword,DoubleCheck;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_input_new_pass);
        PasswordEt = (EditText) findViewById(R.id.editText);
        NewPassword = (EditText) findViewById(R.id.edCheck);
        DoubleCheck = (EditText) findViewById(R.id.edCheck);
    }
    public void OnCheck(View view){
        String password=PasswordEt.getText().toString();
        String newPassword=NewPassword.getText().toString();
        String doubleCheck=DoubleCheck.getText().toString();
        String type = "Newpass";
        Global global =(Global) getApplicationContext().getApplicationContext();
        String UserPass=global.UserPass;
        String UserNum=global.UserNum;
        if(UserPass.equals(password)){
            if(!password.equals(newPassword)){
                if(doubleCheck.equals(newPassword)){
                    BackPassword backgroundWorker = new BackPassword(this);
                    backgroundWorker.execute(type,UserNum,password,newPassword,doubleCheck);
                }
                else{
                    Toast.makeText(getApplicationContext(),"確認密碼輸入錯誤",Toast.LENGTH_SHORT).show();
                }}
            else{
                Toast.makeText(getApplicationContext(),"輸入錯誤",Toast.LENGTH_SHORT).show();
            }}
        else{
            Toast.makeText(getApplicationContext(),"原本密碼輸入錯誤",Toast.LENGTH_SHORT).show();
        }

        //可以辨識是否有此帳號
        // SharedPreferences re = getSharedPreferences("re",MODE_MULTI_PROCESS);
        // re.edit()
        //         .putString("USER",user)
        //         .commit();
    }
}
