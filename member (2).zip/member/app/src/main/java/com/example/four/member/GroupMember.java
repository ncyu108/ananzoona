package com.example.four.member;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import java.util.ArrayList;
public class GroupMember extends AppCompatActivity implements AddBackgrouneWorker.AsyncResponse{
    ListView lv;
    EditText nameTxt;
    EditText yearTxt;
    EditText totalTxt;
    Button addbtn, deletebtn;
    ArrayList<String> names = new ArrayList<String>();
    ArrayAdapter<String> adapter;
    Integer i=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group_member);
        lv = (ListView) findViewById(R.id.list);
        nameTxt = (EditText) findViewById(R.id.Input);
        totalTxt=(EditText)findViewById(R.id.Totalnum);
        yearTxt=(EditText)findViewById(R.id.Year);
        addbtn = (Button) findViewById(R.id.Addbtn);
        deletebtn = (Button) findViewById(R.id.Deletebtn);
        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_single_choice, names);
        lv.setAdapter(adapter);
        //Set selected Item
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> arg0, View v, int pos, long id) {
                nameTxt.setText(names.get(pos));
            }
        });
        //Handle Events
        // doInBackground(name);

        addbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
                // doInBackground();
                add();
            }
        });

        deletebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
                delete();
            }
        });
    }
    private void add() {
        String name = nameTxt.getText().toString();
        String total=totalTxt.getText().toString();
        String year=yearTxt.getText().toString();
        Global globalVariable = (Global)getApplicationContext().getApplicationContext();
        String leader = globalVariable.UserNum;
        //String leader ="10446789";
        String idd = "";
        i = i + 1;
        idd = String.valueOf(i);
        AddBackgrouneWorker asyncTask =new AddBackgrouneWorker((AddBackgrouneWorker.AsyncResponse) GroupMember.this);
        asyncTask.delegate = (AddBackgrouneWorker.AsyncResponse) this;
        asyncTask.execute(leader,name,total,year,idd);
    }
    private void delete() {
        int pos = lv.getCheckedItemPosition();
        String leader ="10446789";
        String type="Delete";
        String renum="";
        if (pos > -1) {
            //remove
            renum = String.valueOf(pos+1);
            //renum.equals(names.get(pos));
            adapter.remove(names.get(pos));
            //refresh
            adapter.notifyDataSetChanged();
            DeBackgroundworker backgroundWorker = new DeBackgroundworker(this);
            backgroundWorker.execute(leader,renum);
            nameTxt.setText("");
            Toast.makeText(getApplicationContext(), "Delete", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(getApplicationContext(), "!!Nothing to Delete", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void processFinish(String result) {

        String name = nameTxt.getText().toString();
        // String recure="";
        String typee="";
        // recure=result;
        if (result.equals("success")) {
            if (!name.isEmpty() && name.length() > 0) {
                adapter.add(name);
                adapter.notifyDataSetChanged();
                //Refresh
                nameTxt.setText("");
                // output.equals("");
                Toast.makeText(getApplicationContext(), "Added" + name, Toast.LENGTH_SHORT).show();
            } else {
                nameTxt.setText("");
                Toast.makeText(getApplicationContext(), "!!Nothing to Add", Toast.LENGTH_SHORT).show();
            }
        } else {
            nameTxt.setText("");
            Toast.makeText(getApplicationContext(), "!!No this person", Toast.LENGTH_SHORT).show();
        }
    }
}

