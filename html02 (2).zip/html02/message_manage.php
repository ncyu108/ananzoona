<?php
include("connect.php");
mysqli_select_db($db, "ananzoona" );
session_start();

$account = $_SESSION['useraccount'];

$sql = "SELECT * FROM member where 帳號 != '$account';";
$rows = mysqli_query($db , $sql);//執行SQL查詢
$num = mysqli_num_rows ($rows);
mysqli_close($db);
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>選擇接收訊息的人</title>
</head>
<center>
<body>
<table border="1">
	<thead>
		<tr>
			<th>NAME</th>
			<th>ACCOUNT</th>
		</tr>
	</thead>
	<tbody>
		<?php
		if($num >0){
			for($i=0 ; $i<$num ; $i++){
				$row = mysqli_fetch_row($rows);
					$name = $row[0];
					$messenge_account = $row[2];
					echo "<tr>";
					echo "<td>" . $row[0] . "</td>";
					echo "<td>" . $row[2] . "</td>";
					echo "<td>"."<a href ='messenge_pass.php?name=" . $row[0] . "'>傳送訊息</a>"."</td>";
					echo "</tr>";
			}
		}
		
		mysqli_free_result($rows);
		?>
	</tbody>
	<form>
		<input type="submit" name="gohome" value="回首頁" formaction="home.php"/>
	</form>
</body>
</center>
</html>

