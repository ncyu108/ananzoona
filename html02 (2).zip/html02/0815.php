
<?php
include("connect.php");
mysqli_select_db($db, "ananzoona" );
$sql = "SELECT * FROM member";
$rows = mysqli_query($db , $sql);//執行SQL查詢
$num = mysqli_num_rows ($rows);
mysqli_close($db);
?>
<?php session_start(); ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>picture</title>
</head>
<center>
<body>
<table border="1">
	<thead>
		<tr>
			<th>NAME</th>
			<th>ACCOUNT</th>
			<th>safereport</th>
		</tr>
	</thead>
	<tbody>
		<?php
		if($num >0){
			for($i=0 ; $i<$num ; $i++){
				$row = mysqli_fetch_row($rows);
					$name = $row[0];
					echo "<tr>";
					echo "<td>" . $row[0] . "</td>";
					echo "<td>" . $row[2] . "</td>";
					
					echo "<td>"."<a href ='safereport.php?name=" . $row[2] . "'>安全回報單</a>"."</td>";
					echo "</tr>";
			}
		}
		
		mysqli_free_result($rows);
		?>
		<form>
	<input type="submit" name="gohome" value="回首頁" formaction="home.php"/>
	</form>
	</tbody>
</body>
</center>
</html>

