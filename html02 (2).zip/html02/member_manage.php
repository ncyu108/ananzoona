<?php session_start();?>
<?php
	include("connect.php");
	mysqli_select_db($db, "ananzoona" );
	if (isset($_POST["send"]))
	{		
		$mail_address = $_POST["mail_address"];
		$cellphone = $_POST["cellphone"];
		$address1 = $_POST["address1"];
		$address2 = $_POST["address2"];
		$account = $_SESSION['useraccount'];
		
		$select = "SELECT * FROM member WHERE 帳號 = '$account';";
		$rows2 = mysqli_query($db,$select);//執行查詢
		$row2 = mysqli_fetch_array($rows2);
		echo $account;
		
		//執行修改程式
		$sqlupdate = "UPDATE member SET 信箱 = '$mail_address',電話 = '$cellphone',通訊地址 = '$address1',戶籍地址 = '$address2' WHERE 帳號 = '".$account."'";
		$rows3 = mysqli_query($db,$sqlupdate);	
		if($row2[3])
		{
			echo '修改成功';
			echo '<script language="javascript">
			alert("修改成功");
			window.location.replace("home.php");
			</script>';
		}
		else
		{
			echo '修改失敗';
			echo '<script language="javascript">
			alert("修改失敗");
			window.location.replace("member_manage.php");
			</script>';
		}
	}
	else 
	{
		$id = $_SESSION['useraccount']; //取得帳號
		//$_SESSION['account'] = $id;
		$sql = "SELECT * FROM member WHERE 帳號 = '$id'";
		$rows = mysqli_query($db,$sql);
		$row = mysqli_fetch_array($rows);
		$_SESSION['username'] = $row[0];
		$mail_address = $row[1];
		$cellphone = $row[4];
		$address1 = $row[5];
		$address2 = $row[7];
		mysqli_free_result($rows);	
	}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>個人資訊管理</title>
</head>
<body>
<h1>編輯個人資料</h1></hr>
<ul>
</ul>
</hr>
<form name="delete" method="post" action="">
	<li>帳號: <?php echo $_SESSION['useraccount'];?>
	<li>姓名: <?php echo $_SESSION['username'];?>
	<li>信箱: <input type="text" name="mail_address" value="<?php echo $mail_address?>"/>
	<li>電話: <input type="text" name="cellphone" value="<?php echo $cellphone?>"/>
	<li>通訊地址: <input type="text" name="address1" value="<?php echo $address1?>"/>
	<li>戶籍地址: <input type="text" name="address2" value="<?php echo $address2?>"/>
	<li>種類: <?php echo $_SESSION['usertype'];?>
	<hr><input type="submit" name="send" value="確認修改" />
	<input type="submit" name="gohome" value="回首頁" formaction="home.php"/>
</form>
</body>
</html>