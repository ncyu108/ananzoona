<!DOCTYPE html>
<?php session_start();?>
<html>
<meta charset="utf-8" />
<head>
<title>Home</title>
</head>
<body>
<form>
<li>歡迎 <?php echo $_SESSION['username'];?>
<li>會員種類 <?php echo $_SESSION['usertype']."</br>";?>
</form>
<form name="home" method="post" action="">
<input type="submit" name="0815" value="安全回報管理" formaction="0815.php"/>
<input type="submit" name="member_manage" value="個人資訊管理" formaction="member_manage.php"/>
<input type="submit" name="member_manager" value="帳號密碼管理" formaction="member_manager.php"/>
<input type="submit" name="message_manage" value="訊息管理" formaction="message_manage.php"/>
<input type="submit" name="logout" value="學生管理(不要按)" formaction="logout.php"/>
<input type="submit" name="suggest" value="評價管理" formaction="suggest.php"/>
<input type="submit" name="logout" value="登出" formaction="logout.php"/>
<input type="submit" name="input" value="匯入帳號" formaction="register.html"/>
</form>
</body>
</html>