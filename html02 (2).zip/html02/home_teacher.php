<!DOCTYPE html>
<?php session_start();?>
<html>
<meta charset="utf-8" />
<head>
<title>Home</title>
</head>
<body>
<form>
<li>歡迎 <?php echo $_SESSION['username'];?>
<li>會員種類 <?php echo $_SESSION['usertype']."</br>";?>
<?php echo "<td>"."<a href ='safereport.php?name=" . $_SESSION['username'] . "'>安全回報單</a>"."</td>";?>
</form>
<a href="0815.php" method="post">安全回報管理</a>
<a href="logout.php" method="post">個人資訊管理</a>
<a href="member_manager.php" method="post">帳號管理</a>
<a href="message.php" method="post">訊息管理</a>
<a href="logout.php" method="post">學生管理</a>
<a href="suggest.php" method="post">評價管理</a>
<a href="logout.php" method="post">登出</a>
</body>
</html>