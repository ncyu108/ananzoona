package com.example.user.test1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements BackgrouneWorker.AsyncResponse {
    ListView lv;
    EditText nameTxt;
    Button addbtn, deletebtn, savebtn;
    ArrayList<String> names = new ArrayList<String>();
    ArrayAdapter<String> adapter;
  //  String result = "";
    Integer i=0;
  //  BackgrouneWorker asyncTask =new BackgrouneWorker(MainActivity.this);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        lv = (ListView) findViewById(R.id.list);
        nameTxt = (EditText) findViewById(R.id.Input);
        addbtn = (Button) findViewById(R.id.Addbtn);
        deletebtn = (Button) findViewById(R.id.Deletebtn);
        savebtn = (Button) findViewById(R.id.Savebtn);
        //   String name = nameTxt.getText().toString();
        //Adapter
        //String name = nameTxt.getText().toString();
        // doInBackground();
        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_single_choice, names);
        lv.setAdapter(adapter);
        //Set selected Item
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> arg0, View v, int pos, long id) {
                nameTxt.setText(names.get(pos));
            }
        });
        //Handle Events
        // doInBackground(name);

        addbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
               // doInBackground();
                add();
            }
        });

        deletebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
                delete();
            }
        });
    }
    private void add() {
        String name = nameTxt.getText().toString();
        String leader ="10446789";
        String idd = "";
        i = i + 1;
        idd = String.valueOf(i);
        BackgrouneWorker asyncTask =new BackgrouneWorker(MainActivity.this);
        asyncTask.delegate = this;
        asyncTask.execute(leader,name,idd);

    }
    private void delete() {
        int pos = lv.getCheckedItemPosition();
        String leader ="10446789";
        String type="Delete";
        String renum="";
        if (pos > -1) {
            //remove
            renum = String.valueOf(pos+1);
            //renum.equals(names.get(pos));
            adapter.remove(names.get(pos));
            //refresh
            adapter.notifyDataSetChanged();
            Backgroundworker backgroundWorker = new Backgroundworker(this);
            backgroundWorker.execute(leader,renum);
            nameTxt.setText("");
            Toast.makeText(getApplicationContext(), "Delete", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(getApplicationContext(), "!!Nothing to Delete", Toast.LENGTH_SHORT).show();
        }

    }
    @Override
    public void processFinish(String result) {

        String name = nameTxt.getText().toString();
        // String recure="";
        String typee="";
        // recure=result;
        if (result.equals("success")) {
            if (!name.isEmpty() && name.length() > 0) {
                //ADD name
                 //String [] data;
                //data[0]=name;
                    adapter.add(name);
                   adapter.notifyDataSetChanged();
                //Refresh
                   nameTxt.setText("");
               // output.equals("");
                   Toast.makeText(getApplicationContext(), "Added" + name, Toast.LENGTH_SHORT).show();
                  } else {
                      nameTxt.setText("");
                       Toast.makeText(getApplicationContext(), "!!Nothing to Add", Toast.LENGTH_SHORT).show();
                   }
            } else {
                nameTxt.setText("");
                Toast.makeText(getApplicationContext(), "!!No this person", Toast.LENGTH_SHORT).show();
            }
        }
    }
