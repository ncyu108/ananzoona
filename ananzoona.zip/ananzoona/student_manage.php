<?php session_start();?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>安安租哪-學生管理</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
		<body class="is-preload">

		<!-- Wrapper -->
			<div id="wrapper">

				<!-- Main -->
					<div id="main">
						<div class="inner">

							<!-- Header -->
								<header id="header">
									<h2><strong>學生管理</strong></h2>
									<name>歡迎，<strong><?php echo $_SESSION['username'];?></strong><?php if($_SESSION['userisonline']==1) {echo '上線中';}?></br>
									會員種類：<?php echo $_SESSION['usertype']."</br>";?></name>
									<ul class="icons">
										<li><a href="#" class="icon fa-twitter"><span class="label">Twitter</span></a></li>
										<li><a href="#" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
									</ul>
								</header>
								</br>
													<div class="col-12">
																<select name="demo-category" id="demo-category">
																	<option value="">學年度</option>
																	<option value="1">107</option>
																	<option value="2">106</option>
																	<option value="3">105</option>
																	<option value="4">104</option>
																</select>
																<select name="demo-category" id="demo-category">
																	<option value="">校區</option>
																	<option value="1">新民</option>
																	<option value="2">蘭潭</option>
																	<option value="3">民雄</option>
																</select>
																<select name="demo-category" id="demo-category">
																	<option value="">系所</option>
																	
																</select>
																<select name="demo-category" id="demo-category">
																	<option value="">年級</option>
																	
																</select>
																<select name="demo-category" id="demo-category">
																	<option value="">審核</option>
																	<option value="1">是</option>
																	<option value="2">否</option>
																</select>
													</div>
													</br>
											<!--		<div class="col-6 col-12-small">
																<input type="checkbox" id="demo-copy" name="demo-copy">
																<label for="demo-copy">審核</label>
															</div>-->
													<ul class="actions">
														<li><a href="#" class="button small">搜尋</a></li>
													</ul>
													<div class="table-wrapper">
														<table>
															<thead>
																<tr>
																	<th>姓名</th>
																	<th>學號</th>
																	<th>當前回報單狀態</th>
																</tr>
															</thead>
															<tbody>
															<?php
$current_year = date("Y")-1911;
include("connect.php");
mysqli_select_db($db, "ananzoona" );
$usertype = $_SESSION['usertype'];
$useraccount = $_SESSION['useraccount'];
if ($usertype == '導師')
{
	$sql = "SELECT * FROM member WHERE 種類 = '學生' && 導師 = '$useraccount' order by 帳號 DESC";
	$rows = mysqli_query($db , $sql);//執行SQL查詢
	$num = mysqli_num_rows ($rows);
	
	if($num >0)
			{
				for($i=0 ; $i<$num ; $i++)
				{
					$row = mysqli_fetch_row($rows);
					
					$sql_group = "SELECT stnumber FROM `group` WHERE stnumber = '$row[0]'";
					$rows_group = mysqli_query($db , $sql_group);//執行SQL查詢
					$row_group = mysqli_fetch_row($rows_group);
					
					$current_safereport = "SELECT 導師複查 FROM safereport WHERE 學年度 = $current_year && 成員 like $row_group[0];";
					$rows_current_safereport = mysqli_query($db , $current_safereport);//執行SQL查詢
					$row_current_safereport = mysqli_fetch_row($rows_current_safereport);
					$num_current_safereport = mysqli_num_rows ($rows_current_safereport);
					
					echo "<tr>";
					echo "<td>"."<a href ='student_safereport.php?account=$row[0]'>$row[2]</a>"."</td>";
					echo "<td>" . $row[0] . "</td>";
					if($num_current_safereport==0)
					{
						echo "<td>尚未填寫安全回報</td>";
					}
					else
					{
						if($row_current_safereport[0]==0)
						{
							echo "<td>尚未審核</td>";
						}
						else
						{
							echo "<td>已審核</td>";
						}
					}
					echo "</tr>";
					//mysqli_free_result($rows2);
					//mysqli_close($db);
				}
				mysqli_free_result($rows);
			}
}
mysqli_close($db);
?>
															</tbody>
														</table>
														</div>
													</form>
													</br>
													<!--<ul class="pagination">
														<li><span class="button disabled">Prev</span></li>
														<li><a href="#" class="page active">1</a></li>
														<li><a href="#" class="page">2</a></li>
														<li><a href="#" class="page">3</a></li>
														<!--<li><span>&hellip;</span></li>
														<li><a href="#" class="page">4</a></li>
														<li><a href="#" class="page">5</a></li>
														<li><a href="#" class="page">6</a></li>
														<li><a href="#" class="button">Next</a></li>
													</ul>-->
						</div>
					</div>
					<div id="sidebar">
						<div class="inner">
							<!-- Menu -->
								<nav id="menu">
									<header class="major">
										<h2>功能</h2>
									</header>
									<ul>
										<li><a href="home.php">首頁</a></li>
										<li><a href="0815.php?sel=<?php 
							include("connect.php");
							mysqli_select_db($db, "ananzoona" );
							$sql2 = "SELECT 學年度 FROM safereport order by 學年度 DESC limit 1";
							$rows2 = mysqli_query($db , $sql2);//執行SQL查詢
							$row = mysqli_fetch_row($rows2);
							echo $row[0];
							?>&check=0">安全回報</a></li>
										<li><a>學生管理</a></li>
										<li>
											<span class="opener">個人設定</span>
											<ul>
												<li><a href="member_manager.php">帳號管理</a></li>
												<li><a href="member_manage.php">個人管理</a></li>
											</ul>
										</li>
										<li><a href="suggest.php">聯繫我們</a></li>
										<?php 
											$usertype = $_SESSION['usertype'];
											if ($usertype == '超級使用者')
												{ 
													echo '<li><a href="register0913.php">匯入帳號</a></li>';
												}
										?>
										<li><a href="logout.php">登出</a></li>
									</ul>
								</nav>
							<!-- Section -->
								<section>
									<header class="major">
										<h2>軍訓組聯絡方式</h2>
									</header>
									<p>服務時間：０８：００～１７：００</p>
									<ul class="contact">
										<li class="fa-envelope-o">meo@mail.ncyu.edu.tw</li>
										<li class="fa-phone">05-2717312</li>
										<li class="fa-home">24小時緊急電話<br />
										05-2717373</li>
									</ul>
								</section>

							<!-- Footer -->
								<footer id="footer">
									<p class="copyright">&copy; 國立嘉義大學</p>
								</footer>

						</div>
					</div>

			</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>