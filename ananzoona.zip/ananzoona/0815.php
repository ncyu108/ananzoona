<?php session_start(); ?>
<?php
include("connect.php");
mysqli_select_db($db, "ananzoona" );
$year = $_GET['sel'];
$usertype = $_SESSION['usertype'];
$useraccount = $_SESSION['useraccount'];
if(isset($_GET['check']))
{
	$check = $_GET['check'];//value = 1 審核
}
else
{
	$check = 0;
}
if ($usertype == '導師')
{
	$sql = "SELECT * FROM safereport WHERE 學年度 = '$year' && 導師複查 = $check && 導師 = '$useraccount' order by 學年度 DESC";
	$rows = mysqli_query($db, $sql);//執行SQL查詢
	
	$num = mysqli_num_rows ($rows);
	$per = 5; //每頁顯示項目數量
	$pages = ceil($num/$per); //取得不小於值的下一個整數
	if (!isset($_GET["page"]))
	{ //假如$_GET["page"]未設置
        $page=1; //則在此設定起始頁數
    } 
	else 
	{
        $page = intval($_GET["page"]); //確認頁數只能夠是數值資料
    }
	$start = ($page-1)*$per; //每一頁開始的資料序號
	$rows = mysqli_query($db, $sql.' LIMIT '.$start.', '.$per );//執行SQL查詢
}
elseif ($usertype == '教官')
{
	$sql = "SELECT * FROM safereport WHERE 學年度 = '$year' && 導師複查 = 1 && 教官複查 = $check order by 學年度 DESC";
	$rows = mysqli_query($db , $sql);//執行SQL查詢
	$num = mysqli_num_rows ($rows);
	$per = 5; //每頁顯示項目數量
	$pages = ceil($num/$per); //取得不小於值的下一個整數
	
	if (!isset($_GET["page"]))
	{ //假如$_GET["page"]未設置
        $page=1; //則在此設定起始頁數
    } 
	else 
	{
        $page = intval($_GET["page"]); //確認頁數只能夠是數值資料
    }
	$start = ($page-1)*$per; //每一頁開始的資料序號
	$rows = mysqli_query($db, $sql.' LIMIT '.$start.', '.$per );//執行SQL查詢
}
elseif ($usertype == '學生')
{
	$sql = "SELECT * FROM safereport WHERE 學年度 = '$year' && 成員 = $useraccount order by 學年度 DESC";
	$rows = mysqli_query($db , $sql);//執行SQL查詢
	$num = mysqli_num_rows ($rows);
	$per = 5; //每頁顯示項目數量
	$pages = ceil($num/$per); //取得不小於值的下一個整數
	if (!isset($_GET["page"]))
	{ //假如$_GET["page"]未設置
        $page=1; //則在此設定起始頁數
    } 
	else 
	{
        $page = intval($_GET["page"]); //確認頁數只能夠是數值資料
    }
	$start = ($page-1)*$per; //每一頁開始的資料序號
	$rows = mysqli_query($db, $sql.' LIMIT '.$start.', '.$per );//執行SQL查詢
}
else
{
	$sql = "SELECT * FROM safereport WHERE 學年度 = '$year'";
	$rows = mysqli_query($db , $sql);//執行SQL查詢
	$num = mysqli_num_rows ($rows);
	$per = 5; //每頁顯示項目數量
	$pages = ceil($num/$per); //取得不小於值的下一個整數
	if (!isset($_GET["page"]))
	{ //假如$_GET["page"]未設置
        $page=1; //則在此設定起始頁數
    } 
	else 
	{
        $page = intval($_GET["page"]); //確認頁數只能夠是數值資料
    }
	$start = ($page-1)*$per; //每一頁開始的資料序號
	$rows = mysqli_query($db, $sql.' LIMIT '.$start.', '.$per );//執行SQL查詢
}

mysqli_close($db);
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>安安租哪-安全回報</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
		<body class="is-preload">
		<script>
function node(name, child){
	this.name=name;
	this.child=child;
}

function dataHierarchy(){
	// 蘭潭校區
	var lantan=new Array();
	var i=0;
	//lantan[i++]=new node("學院");
	lantan[i++]=new node("農學院", ["農藝學系", "園藝學系", "森林暨自然資源學系","木質材料與設計學系","動物科學系","生物農業科技學系","景觀學系","植物醫學系"]);
	lantan[i++]=new node("理工學院", ["電子物理學系", "應用化學系", "應用數學系", "資訊工程學系","生物機電工程學系","土木與水資源工程學系","電機工程學系","機械與能源工程學系"]);
	lantan[i++]=new node("生命科學學院", ["食品科學系", "水生生物科學系", "生物資源學系","生化科技學系","微生物免疫與生物藥學系"]);
	
	// 民雄校區
	var menhun=new Array();
	var i=0;
	menhun[i++]=new node("師範學院", ["教育學系", "輔導與諮商學系", "體育與健康休閒學系","特殊教育學系","幼兒教育學系","數位學習設計與管理學系"]);
	menhun[i++]=new node("人文藝術學院", ["中國文學系", "視覺藝術系","應用歷史學系","外國語言學系","音樂學系"]);
	
	// 新民校區
	var xhinmen=new Array();
	var i=0;
	xhinmen[i++]=new node("管理學院", ["企業管理學系", "應用經濟學系", "生物事業管理學系","資訊管理學系","財務金融學系","行銷與觀光管理學系"]);
	xhinmen[i++]=new node("獸醫學院", ["獸醫學系"]);
	
	var wwwwwww=new Array();
	var i=0;
	var output=new Array();
	var i=0;
	output[i++]=new node("-----校區-----", wwwwwww);
	output[i++]=new node("蘭潭", lantan);
	output[i++]=new node("民雄", menhun);
	output[i++]=new node("新民", xhinmen);

	return(output);
}
dataTree=dataHierarchy();

// 第三個欄位被更動後的反應動作
//function onChangeColumn3(){
	//updatePath();
//}

// 第二個欄位被更動後的反應動作
function onChangeColumn2(){
	form=document.theForm;
	index1=form.column1.selectedIndex;
	index2=form.column2.selectedIndex;
	index3=form.column3.selectedIndex;
	// Create options for column 3
	for (i=0;i<dataTree[index1].child[index2].child.length;i++)
		form.column3.options[i]=new Option(dataTree[index1].child[index2].child[i], dataTree[index1].child[index2].child[i]);
	form.column3.options.length=dataTree[index1].child[index2].child.length;
	updatePath();
}

// 第一個欄位被更動後的反應動作
function onChangeColumn1() {
	form=document.theForm;
	index1=form.column1.selectedIndex;
	index2=form.column2.selectedIndex;
	index3=form.column3.selectedIndex;
	// Create options for column 2
	for (i=0;i<dataTree[index1].child.length;i++)
		form.column2.options[i]=new Option(dataTree[index1].child[i].name, dataTree[index1].child[i].name);
	form.column2.options.length=dataTree[index1].child.length;
	// Clear column 3
	form.column3.options.length=0;
	updatePath();
}

// 修改所顯示的路徑
/*function updatePath(){
	form=document.theForm;
	index1=form.column1.selectedIndex;
	index2=form.column2.selectedIndex;
	index3=form.column3.selectedIndex;
	if ((index1>=0) && (index2>=0) && (index3>=0)) {
		text1=form.column1.options[index1].text;
		text2=form.column2.options[index2].text;
		text3=form.column3.options[index3].text;
		form.path.value=text1+" ==> "+text2+" ==> "+text3;
	} else
		form.path.value="";
}*/
</script>
		<!-- Wrapper -->
			<div id="wrapper">

				<!-- Main -->
					<div id="main">
						<div class="inner">

							<!-- Header -->
								<header id="header">
									<h2><strong>安全回報</strong></h2>
									<name>歡迎，<strong><?php echo $_SESSION['username'];?></strong><?php if($_SESSION['userisonline']==1) {echo '上線中';}?></br>
									會員種類：<?php echo $_SESSION['usertype']."</br>";?></name>
									<ul class="icons">
										<li><a href="#" class="icon fa-twitter"><span class="label">Twitter</span></a></li>
										<li><a href="#" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
									</ul>
								</header>
								</br>
								
													<div class="table-wrapper">
													<div class="col-12">
													
													<form class="a" name="theForm">
																<select name="demo-category" id="demo-category">
																	<option value="">學年度</option>
																	<option value="1">107</option>
																	<option value="2">106</option>
																	<option value="3">105</option>
																	<option value="4">104</option>
																</select>																																
																<select name="column1" size=1 onChange="onChangeColumn1();">
																<script>
																	for (i=0; i<dataTree.length; i++)
																	document.writeln("<option value=\""+dataTree[i].name+"\">"+dataTree[i].name);
																</script>
																</select>
																<select name="column2" size=1 onChange="onChangeColumn2();">
																</select>
																<select name="column3" size=1 onChange="onChangeColumn3();">
																</select>																																																								
																<select name="demo-category" id="demo-category">
																	<option value="">年級</option>																	
																	<option value="1">一</option>
																	<option value="2">二</option>
																	<option value="3">三</option>
																	<option value="4">四</option>
																</select>
																<select name="demo-category" id="demo-category">
																	<option value="">審核</option>
																	<option value="1">是</option>
																	<option value="2">否</option>
																</select>
																</form>
													</div>
											<!--		<div class="col-6 col-12-small">
																<input type="checkbox" id="demo-copy" name="demo-copy">
																<label for="demo-copy">審核</label>
															</div>-->
													<ul class="actions">
														<li><a href="#" class="button small">搜尋</a></li>
													</ul>
														<table>
															<thead>
																<tr>
																	<th>學年度</th>
																	<th>成員</th>
																	<th>房屋資訊</th>
																</tr>
															</thead>
															<tbody>
																<?php
			if($num >0)
			{
				for($i=0 ; $i<$per ; $i++)
				{
					$row = mysqli_fetch_row($rows);
					include("connect.php");
					mysqli_select_db($db, "ananzoona" );
					if($row[1] != NULL){
					$sql3 = "SELECT 房屋地址 FROM house WHERE ID = $row[1]";
					$rows3 = mysqli_query($db , $sql3);//執行SQL查詢
					$row3 = mysqli_fetch_row($rows3);
					$name = $row[0];
					echo "<tr>";
					echo "<td>" . $row[13] . "</td>";
					echo "<td>" . $row[2] . "</td>";
					
					echo "<td>"."<a href ='safereport.php?name=$row[1]&year=$row[13]'>$row3[0]</a>"."</td>";
					echo "</tr>";
					mysqli_free_result($rows3);
					}
					mysqli_close($db);
				}
				mysqli_free_result($rows);
			}
		?>
		<form>
			<p>學年度
<select name="sel" id="demo-category">
				<?php
					include("connect.php");
					mysqli_select_db($db, "ananzoona" );
					$sql2 = "SELECT 學年度 FROM safereport order by 學年度 DESC";
					$rows2 = mysqli_query($db , $sql2);//執行SQL查詢
					$num2 = mysqli_num_rows ($rows2);
					mysqli_close($db);
					$year = '';
					
					for($i=0;$i<$num2;$i++)
					{
						$row = mysqli_fetch_row($rows2);
						if ($row[0] != $year)
						{
							echo "<option value='". $row[0] ."'>". $row[0];
						}
						$year = $row[0];
					}
				?>
				</select>
			<input type="checkbox" value="1" name="check" <?php 
			$usertype = $_SESSION['usertype'];
			if ($usertype == '學生')
			{ 
				echo 'hidden=""';
			}
		?>><?php 
			$usertype = $_SESSION['usertype'];
			if ($usertype != '學生')
			{ 
				echo '審核';
			}
		?>
		<input type="submit" name="button" id="button" value="搜尋" />
															</tbody>
														</div>
													</form>
														</table>
													</br>
													<ul class="pagination">
													<?php
    //分頁頁碼
	include("connect.php");
	mysqli_select_db($db, "ananzoona" );
	$sql2 = "SELECT 學年度 FROM safereport order by 學年度 DESC limit 1";
	$rows2 = mysqli_query($db , $sql2);//執行SQL查詢
	$row = mysqli_fetch_row($rows2);
	
	$sel = '&sel='.$row[0].'&check=0';
	
    echo '共 '.$num.' 筆-在 '.$page.' 頁-共 '.$pages.' 頁';
    echo "<br /><a href=?page=1".$sel.">首頁</a> ";
    echo "第 ";
    for( $i=1 ; $i<=$pages ; $i++ ) {
        if ( $page-3 < $i && $i < $page+3 ) {
			
            echo "<li><a href=?page=".$i.$sel.">".$i."</a></li> ";
        }
    } 
    echo " 頁 <a href=?page=".$pages.$sel.">末頁</a><br /><br />";
?>							
														<!--<li><span class="button disabled">Prev</span></li>
														<li><a href="#" class="page active">1</a></li>
														<li><a href="#" class="page">2</a></li>
														<li><a href="#" class="page">3</a></li>
														<!--<li><span>&hellip;</span></li>
														<li><a href="#" class="page">4</a></li>
														<li><a href="#" class="page">5</a></li>
														<li><a href="#" class="page">6</a></li>
														<li><a href="#" class="button">Next</a></li>-->
													</ul>
						</div>
					</div>
					<div id="sidebar">
						<div class="inner">
							<!-- Menu -->
								<nav id="menu">
									<header class="major">
										<h2>功能</h2>
									</header>
									<ul>
										<li><a href="home.php">首頁</a></li>
										<li><a href="0815.php?sel=<?php 
							include("connect.php");
							mysqli_select_db($db, "ananzoona" );
							$sql2 = "SELECT 學年度 FROM safereport order by 學年度 DESC limit 1";
							$rows2 = mysqli_query($db , $sql2);//執行SQL查詢
							$row = mysqli_fetch_row($rows2);
							echo $row[0];
							?>&check=0">安全回報</a></li>
										<li><a href="student_manage.php">學生管理</a></li>
										<li>
											<span class="opener">個人設定</span>
											<ul>
												<li><a href="member_manager.php">帳號管理</a></li>
												<li><a href="member_manage.php">個人管理</a></li>
											</ul>
										</li>
										<li><a href="suggest.php">聯繫我們</a></li>
										<?php 
											$usertype = $_SESSION['usertype'];
											if ($usertype == '超級使用者')
												{ 
													echo '<li><a href="register0913.php">匯入帳號</a></li>';
												}
										?>
										<li><a href="logout.php">登出</a></li>
									</ul>
								</nav>
							<!-- Section -->
								<section>
									<header class="major">
										<h2>軍訓組聯絡方式</h2>
									</header>
									<p>服務時間：０８：００～１７：００</p>
									<ul class="contact">
										<li class="fa-envelope-o">meo@mail.ncyu.edu.tw</li>
										<li class="fa-phone">05-2717312</li>
										<li class="fa-home">24小時緊急電話<br />
										05-2717373</li>
									</ul>
								</section>

							<!-- Footer -->
								<footer id="footer">
									<p class="copyright">&copy; 國立嘉義大學</p>
								</footer>

						</div>
					</div>

			</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>
		
	</body>
</html>