<!doctype>
<?php session_start(); 
?>
<html>
<head>
<meta charset="utf-8"/>
<title>留言</title>
</head>
<body>
<form action="message_transfer.php" method="post">
	<table>
		<tr>
			<td>
				<textarea name="MessageALL" row="4" cols="30" style="width:800px;height:500px;" readonly>
					<?php 
						$name = $_GET["name"];
						$_SESSION['messenge_member'] = $name;
						$name2 = $_SESSION['username'];
						echo $name;
						echo $name2;
						echo "\n";
						
						include("connect.php");
						mysqli_select_db($db, "ananzoona" );
						$sql2 = "SELECT * FROM message WHERE (接收者姓名 = '$name' && 傳送者姓名 = '$name2')||(接收者姓名 = '$name2' && 傳送者姓名 = '$name');";
						$rows2 = mysqli_query($db , $sql2);//執行SQL查詢
						$num = mysqli_num_rows ($rows2);
						$num2 = $num - 100;
						
						if($num < 100 && $num != 0)
						{
							for($i=0 ; $i<$num ; $i++)
							{
								$row2 = mysqli_fetch_row($rows2);
								$messenge_account = $row2[2];//接收者姓名
								$text = $row2[5];//訊息
								$message_account = $row2[4];//傳出者姓名
								$result = $message_account."-->".$text."-->".$messenge_account."\n";
								echo $result;
							}
							mysqli_free_result($rows2);
						}
						elseif($num == 0)
						{
							echo '趕快開始聊天吧';
						}
						else
						{
							$sql3 = "SELECT * FROM message WHERE (接收者姓名 = '$name' && 傳送者姓名 = '$name2')||(接收者姓名 = '$name2' && 傳送者姓名 = '$name') LIMIT $num2,100 ;";
							$rows3 = mysqli_query($db , $sql3);//執行SQL查詢
							$num3 = mysqli_num_rows ($rows3);
							
							for($i=0 ; $i<$num3 ; $i++)
							{
								$row3 = mysqli_fetch_row($rows3);
								$messenge_account = $row3[2];//接收者姓名
								$text = $row3[5];//訊息
								$message_account = $row3[4];//傳出者姓名
								$result = $message_account."-->".$text."-->".$messenge_account."\n";
								echo $result;
							}
						}
					?>
				</textarea>
			</td>
			<td>姓名：
			<?php echo $_SESSION["username"]; ?>
				<td>
					傳送給
				</td>
				<td>姓名：
				<?php
					$name = $_GET["name"];
					$_SESSION['messenge_member'] = $name;
					echo $_SESSION['messenge_member']; 
					$username = $_SESSION["username"];
					
					include("connect.php");
					mysqli_select_db($db, "ananzoona" );
					//查詢訊息
					$sql = "SELECT 帳號 FROM member WHERE 姓名 = '$name';";
					$rows = mysqli_query($db , $sql);//執行SQL查詢
					//將未讀變已讀
					$update = "UPDATE message SET 已讀 = TRUE WHERE 接收者姓名 = '$username' && 傳送者姓名 = '$name' && 已讀 = FALSE;";
					$rows2 = mysqli_query($db , $update);//執行SQL查詢
					$num = mysqli_num_rows ($rows);
					if($num >0)
					{
						for($i=0 ; $i<$num ; $i++)
						{
							$row = mysqli_fetch_row($rows);
							$messenge_account = $row[0];
					}
					$_SESSION['messenge_account'] = $messenge_account;
					}
					mysqli_free_result($rows);
				?>
				</td>
			</td>
		</tr>
		<tr></tr>
		<tr>
			<td>
				留言：<textarea name="Message" row="4" cols="30"></textarea>
			</td>
		</tr>
	</table>
	<input type="submit" name="Send" value="送出留言">
	<input type="reset" name="Reset" value="重設欄位">
	<input type="submit" name="gohome" value="回前頁" formaction="message_manage.php"/>
</form>
</body>
</html>