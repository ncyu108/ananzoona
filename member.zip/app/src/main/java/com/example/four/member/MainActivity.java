package com.example.four.member;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
EditText UsernameEt,PasswordEt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        UsernameEt = (EditText) findViewById(R.id.usernameet);
        PasswordEt = (EditText) findViewById(R.id.passwordet);

    }
    public void OnLogin(View view){
        String username=UsernameEt.getText().toString();
        String password=PasswordEt.getText().toString();
        String type = "login";
        BackgroundWorker backgroundWorker = new BackgroundWorker(this);
        backgroundWorker.execute(type,username,password);
        //可以辨識是否有此帳號
        String user= UsernameEt.getText().toString();
        SharedPreferences re = getSharedPreferences("re",MODE_MULTI_PROCESS);
        re.edit()
                .putString("USER",user)
                .commit();
    }
    public void OpenReg(View view){

        startActivity(new Intent(this,Register.class));
    }
}
