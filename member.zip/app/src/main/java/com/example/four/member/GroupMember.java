package com.example.four.member;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class GroupMember extends AppCompatActivity {
    ListView lv;
    EditText nameTxt;
    Button addbtn, deletebtn, savebtn;
    ArrayList<String> names = new ArrayList<String>();
    ArrayAdapter<String> adapter;
    //  String result = "";
    Integer i=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group_member);
        lv = (ListView) findViewById(R.id.list);
        nameTxt = (EditText) findViewById(R.id.Input);
        addbtn = (Button) findViewById(R.id.Addbtn);
        deletebtn = (Button) findViewById(R.id.Deletebtn);
        savebtn = (Button) findViewById(R.id.Savebtn);

        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_single_choice, names);
        lv.setAdapter(adapter);
        //Set selected Item
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> arg0, View v, int pos, long id) {
                nameTxt.setText(names.get(pos));
            }
        });
        addbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
                // doInBackground();
                add();
            }
        });

        deletebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
                delete();
            }
        });
        savebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
                save();
            }
        });

    }
    private void add() {
        String name = nameTxt.getText().toString();
        String leader ="1044621";
        String type="Add";
        String idd = "";
        //type.equals("Add");
        BackgroundWorker backgroundWorker = new BackgroundWorker(this, new BackgroundWorker.MyCallback() {
            @Override
            public void onResult(String result) {
                String name = nameTxt.getText().toString();
                // String recure="";
                String typee="";
                // recure=result;
                if (result.equals("success")) {
                    if (!name.isEmpty() && name.length() > 0) {
                        //ADD name
                        // String [] data;
                        //data[0]=name;

                        adapter.add(name);
                        i = i + 1;
                        adapter.notifyDataSetChanged();
                        //Refresh
                        nameTxt.setText("");
                        //result.equals("");
                        Toast.makeText(getApplicationContext(), "Added" + name, Toast.LENGTH_SHORT).show();
                    } else {
                        nameTxt.setText("");
                        Toast.makeText(getApplicationContext(), "!!Nothing to Add", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    nameTxt.setText("");
                    Toast.makeText(getApplicationContext(), "!!No this person", Toast.LENGTH_SHORT).show();
                }
            }
        });
        idd = String.valueOf(i);
        backgroundWorker.execute(type,leader,name,idd);
        //  type.equals("register");
        // backgroundWorker.execute(type,name,idd);
        //nameTxt.setText("");

    }

    private void delete() {
        int pos = lv.getCheckedItemPosition();
        if (pos > -1) {
            //remove
            adapter.remove(names.get(pos));
            //refresh
            adapter.notifyDataSetChanged();
            nameTxt.setText("");
            Toast.makeText(getApplicationContext(), "Delete", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(getApplicationContext(), "!!Nothing to Delete", Toast.LENGTH_SHORT).show();
        }


    }

    private void save() {
        int pos = lv.getCheckedItemPosition();
        if (pos > -1) {
            //remove
            adapter.remove(names.get(pos));

            Toast.makeText(getApplicationContext(), "Sucess", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(getApplicationContext(), "!!False", Toast.LENGTH_SHORT).show();
        }


    }
}