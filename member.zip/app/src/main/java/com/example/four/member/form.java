package com.example.four.member;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class form extends AppCompatActivity {
//student messeage
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form);

    }
    public void Topersonal(View view)
    {  Intent it = new Intent(form.this,ToPersonal.class);
        startActivity(new Intent(this,ToPersonal.class));
    }
    public void Toassess(View view)
    {  Intent it = new Intent(form.this,to_assess.class);
        startActivity(new Intent(this,to_assess.class));
    }
    public void Togroup(View view)
    {  Intent it = new Intent(form.this,GroupMember.class);
        startActivity(new Intent(this,GroupMember.class));
    }
}
