package com.example.four.member;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class ToPersonal extends AppCompatActivity{

    ListView lv1;
    ListView lv2;
    ArrayAdapter<String> adapter;
    String readperson_url = "http://10.3.204.7/personaldata.php";
    InputStream is = null;
    String line = null;
    String result =null;
    String[] data;
    String str =null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_to_personal);
        SharedPreferences testusername = getSharedPreferences("re",MODE_PRIVATE);
        str=testusername.getString("USER","");
        lv1=(ListView)findViewById(R.id.listView1);
        lv2=(ListView)findViewById(R.id.listView2);
      StrictMode.setThreadPolicy((new StrictMode.ThreadPolicy.Builder().permitNetwork().build()));

        getData("1",str);
       adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,data);
        lv1.setAdapter(adapter);
        getData("2",str);
        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,data);
        lv2.setAdapter(adapter);
    }
    private void getData(String a,String b){
        try {
            String user_name = b;
            URL url = new URL(readperson_url);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            con.setDoOutput(true);
            con.setDoInput(true);
            OutputStream outputStream = con.getOutputStream();
            BufferedWriter bufferedWriter =new BufferedWriter(new OutputStreamWriter(outputStream,"UTF-8"));
            String post_data = URLEncoder.encode("user_name","UTF-8")+"=" + URLEncoder.encode(user_name,"UTF-8");
            bufferedWriter.write(post_data);
            bufferedWriter.flush();
            bufferedWriter.close();
            outputStream.close();
            InputStream inputStream = con.getInputStream();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream,"iso-8859-1"));
            is = new BufferedInputStream(con.getInputStream());
           // tvname.setText(data[0]);
        }catch (Exception e){
            e.printStackTrace();
        }
        try {
            BufferedReader br =new BufferedReader(new InputStreamReader(is));
            StringBuilder sb =new StringBuilder();
           while ((line=br.readLine())!=null){
                sb.append(line+"\n");

            }
            is.close();
            result=sb.toString();
        }catch (Exception e){
           e.printStackTrace();
        }
       try{
            JSONArray ja=new JSONArray(result);
            JSONObject jo = null;
          data = new String[ja.length()];
           for(int i=0;i<ja.length();i++){
               jo=ja.getJSONObject(i);
               if(a=="1") {
                   data[i] = jo.getString("username");
               }
               if(a=="2"){
                   data[i] = jo.getString("name");
               }
           }
       }catch (Exception e){
        e.printStackTrace();
        }
        }
}
